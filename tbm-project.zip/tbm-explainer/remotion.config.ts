import {Config} from '@remotion/cli/config';

// Every call is guarded so a renamed option in a future Remotion 4.x can never crash config loading.
const C: any = Config;
const set = (fn: string, ...a: any[]) => { try { C[fn]?.(...a); } catch (e) { /* ignore */ } };

set('setVideoImageFormat', 'jpeg');
set('setJpegQuality', 92);
set('setCodec', 'h264');
set('setPixelFormat', 'yuv420p');
set('setCrf', 18);
set('setOverwriteOutput', true);
// WebGL in headless Linux / GitHub Actions needs a software GL backend. Override with --gl=swangle if frames are black.
set('setChromiumOpenGlRenderer', 'angle');
// Procedural textures + heavy 3D frames can be slow on CPU-only runners.
set('setDelayRenderTimeoutInMilliseconds', 300000);
