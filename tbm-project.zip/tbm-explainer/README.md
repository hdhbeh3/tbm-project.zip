# TBM Explainer Short — Remotion 4 + three.js (1080×1920, 30 fps, 41.999 s)

Procedural 3D Tunnel Boring Machine explainer. The supplied voiceover (`public/audio/voiceover.wav`, untouched) is the master clock:
1260 frames = 41.999 s. Scene cuts, captions, mechanical beats and SFX all read `src/data/timeline.json`.

| Scene | Time | Narration beat → animation |
|---|---|---|
| 1 Giant machine | 0.00–5.31 | rapid push-in on the cutterhead in its launch bore, dust, light shafts |
| 2 Cutterhead | 5.31–12.23 | cutaway section; 48 disc cutters roll on the face, chips fly; discs glow subtle yellow from "crushes solid rock"; close-up on "dozens of … discs" |
| 3 Hydraulic thrust | 12.23–19.84 | "As it spins" head → "hydraulic cylinders push" 16 rods extend 0.8→1.7 m with blue pressure flow → "rocks fall into buckets" |
| 4 Conveyor | 19.84–25.40 | camera tracks rocks from chute → hopper → belt; belt cleats/rollers move; path glows yellow |
| 5 Segments | 25.40–34.37 | rods retract; erector lifts, rotates and seats 6 concrete segments (key last) → complete ring at 33.67 s; orbit ends behind the ring |
| 6 Reveal | 34.37–42.00 | side cutaway rolls to vertical, pulls back; all 7 systems labelled in narration order; cutterhead→ top, finished tunnel below |

## Render on GitHub Actions from Android (no manual file editing)
Android file pickers cannot upload folders, so the workflow can run straight from this ZIP:
1. Create a GitHub repo. **Add file → Upload files** → upload `tbm-project.zip` (one file, ~9 MB).
2. **Add file → Create new file**, name it exactly `.github/workflows/render.yml`, paste the contents of `RENDER_WORKFLOW.yml`, commit.
   (If you extract the ZIP and upload the files instead, the workflow detects `package.json` and skips unzipping.)
3. **Actions → Render TBM Short → Run workflow**. Start with mode **stills** (6 test frames, minutes). Then **guides** (half-res video with red safe-zone overlay), **preview**, **full**.
4. Open the finished run → **Artifacts** → download. If frames are black choose `gl = swangle` (or `swiftshader`).

## Local
`npm install` → `npm run studio` (preview) → `npm run render` (writes `out/tbm-short.mp4`).
`npm run check:safe` verifies the shot subjects stay inside the Shorts safe zone. `npm run audio` regenerates the music/SFX (needs python3 + numpy + scipy).

## Safe zone (top 12 %, right 18 %, bottom 22 %)
The camera principal point is shifted so every shot's subject is centred in the safe rectangle (x ≤ 885, 230 ≤ y ≤ 1498). Captions end at y = 1478 and are ≤ x 885; labels are clamped to y 230–1290 and x ≤ 870.

## Tuning
`src/config.ts` holds exposure / light intensities / fog / caption size. Edit that one file if the first render is too dark or bright.

## Known limitations (read these)
* **Not rendered or run by the author.** The authoring environment had no internet, so Remotion, three.js and a browser were never executed. Verified there: import graph bundles, type-check of own code against stubs, camera/safe-zone math, erector/thrust/head synchronisation, audio levels, YAML. Unverified: actual visuals, lighting brightness, WebGL on the runner, render time, exact dependency resolution.
* "Photorealistic" is not achievable procedurally: it is PBR-lit 3D geometry with procedural textures, not photographic. No depth-of-field or bloom (post-processing not used).
* Cutaway rock/machine are clipped with a plane (x ≤ 0); scene 1 is the exterior view inside an open launch bore.
* Caption chunks use measured pauses + character-rate estimates (no speech-to-text available), so a caption may be ~0.1–0.2 s off.
* Motion is time-compressed for clarity (rods stroke, ring built in ~8 s, cutting slows during ring build but the head keeps turning slowly).
* Remotion needs a company licence for larger commercial teams: https://remotion.pro/license
