#!/usr/bin/env python3
"""Generates public/audio/bed.wav : original music + synchronized SFX, ducked under the REAL voiceover.
Requires: numpy, scipy.   Run from repo root:  python3 tools/make_audio.py
Timing comes from src/data/timeline.json (same file the video uses)."""
import json, numpy as np
from scipy import signal
from scipy.io import wavfile

SR = 44100
tl = json.load(open('src/data/timeline.json'))
DUR = tl['durationSec']; N = int(SR * DUR)
rng = np.random.default_rng(11)
t = np.arange(N) / SR
cuts = [s['start'] for s in tl['scenes']] + [tl['scenes'][-1]['end']]

def sos(kind, fc, order=2):
    return signal.butter(order, fc, kind, fs=SR, output='sos')
def lp(x, fc, o=2): return signal.sosfilt(sos('low', fc, o), x)
def hp(x, fc, o=2): return signal.sosfilt(sos('high', fc, o), x)
def bp(x, lo, hi, o=2): return signal.sosfilt(sos('band', [lo, hi], o), x)
def sm(x, a, b): x = np.clip((x - a) / (b - a), 0, 1); return x * x * (3 - 2 * x)
def win(a, b, fi=0.4, fo=0.4): return sm(t, a, a + fi) * (1 - sm(t, b - fo, b))
def stereo(f): return np.stack([f(), f()], 1)            # decorrelated L/R
def place(buf, snd, t0, gain=1.0, pan=0.0):
    i = int(t0 * SR)
    if i >= N or i < 0: return
    n = min(len(snd), N - i)
    buf[i:i + n, 0] += snd[:n] * gain * (1 - max(pan, 0))
    buf[i:i + n, 1] += snd[:n] * gain * (1 + min(pan, 0))
def tt(d): return np.arange(int(d * SR)) / SR

def reverb(x, rt=1.4, wet=0.35):
    n = int(SR * rt); ir = rng.standard_normal(n) * np.exp(-np.arange(n) / (SR * rt / 5)); ir = lp(ir, 3500)
    ir /= np.abs(ir).sum() ** 0.5 * 4
    y = signal.fftconvolve(x, ir)[:len(x)]
    return x * (1 - wet) + y * wet * 4

# ---------------- music bus ----------------
music = np.zeros((N, 2))
# sub drone
drone = 0.5 * np.sin(2 * np.pi * 55 * t) + 0.25 * np.sin(2 * np.pi * 82.4 * t + 1.0 * np.sin(2 * np.pi * 0.07 * t))
drone *= 0.7 + 0.3 * np.sin(2 * np.pi * 0.11 * t)
music += drone[:, None] * 0.55
# pad: Am F C G, saw voices
chords = [(110, 130.8, 164.8), (87.3, 110, 130.8), (130.8, 164.8, 196), (98, 123.5, 146.8)]
seg = 4.8
pad = np.zeros((N, 2))
for k in range(int(np.ceil(DUR / seg))):
    a, b = k * seg, (k + 1) * seg
    env = sm(t, a - 0.7, a + 0.9) * (1 - sm(t, b - 0.7, b + 0.9)) if k < 8 else 0
    for f in chords[k % 4]:
        for ch, det in ((0, 0.996), (1, 1.004)):
            pad[:, ch] += signal.sawtooth(2 * np.pi * f * det * t) * env * 0.05
pad = lp(pad, 650)
level = 0.35 + 0.65 * sm(t, 0, 4) * 0 + 0.25 * sm(t, 5, 12) + 0.15 * sm(t, 25, 34) + 0.35 * sm(t, 34, 38)
music += pad * (0.6 + level[:, None])
# kick + metallic clank, 96 BPM
beat = 60 / 96
kl = np.clip(0.55 + 0.45 * sm(t, 5, 12) - 0.25 * win(25.6, 34.0, 1, 1) + 0.3 * sm(t, 34.4, 38), 0, 1.2)
for k in range(int(DUR / beat)):
    tb = k * beat; g = np.interp(tb, t, kl)
    d = tt(0.35); ph = 2 * np.pi * np.cumsum(45 + 70 * np.exp(-d / 0.04)) / SR
    place(music, np.sin(ph) * np.exp(-d / 0.16), tb, 0.9 * g)
    if k % 2 == 1:
        c = bp(rng.standard_normal(int(.12 * SR)), 1800, 5200) * np.exp(-tt(.12) / 0.03)
        place(music, c, tb, 0.10 * g, pan=0.3 * (-1) ** k)
# ---------------- SFX bus ----------------
sfx = np.zeros((N, 2))
# underground ambience (brown rumble + air + drips)
amb = stereo(lambda: lp(rng.standard_normal(N), 90) * 9 + hp(lp(rng.standard_normal(N), 1400), 400) * 0.35)
sfx += amb * 0.45
for _ in range(14):
    f0 = rng.uniform(900, 1500); d = tt(0.35)
    place(sfx, reverb(np.sin(2 * np.pi * f0 * d) * np.exp(-d / 0.05), 1.0, .5), rng.uniform(0.5, 41), 0.06, pan=rng.uniform(-.6, .6))
# heavy rotating machinery (gear whine + AM)
mach = lp(signal.sawtooth(2 * np.pi * 41 * t), 320) * (0.6 + 0.4 * np.sin(2 * np.pi * 4.4 * t))
mach += 0.4 * lp(signal.sawtooth(2 * np.pi * 123 * t), 600) * (0.5 + 0.5 * np.sin(2 * np.pi * 4.4 * t + 1))
sfx += (mach * (0.55 * win(0, 25.2, 0.5, 1.2) + 0.2 * win(25.2, 34, 1, 1) + 0.7 * win(34, 42, 1.2, 0.6)))[:, None] * 0.5
# steel grinding on rock
gr = bp(rng.standard_normal(N), 700, 2800) * (0.5 + 0.5 * np.sin(2 * np.pi * 7 * t + 2 * np.sin(2 * np.pi * 0.9 * t)))
gw = 0.5 * win(0.3, 5.3, .3, .3) + 1.0 * win(5.3, 12.2, .4, .4) + 0.55 * win(12.2, 19.8, .5, .5) + 0.4 * win(34.4, 42, 1, .5)
sfx += (gr * gw)[:, None] * 0.55
# rock-crushing impacts (Poisson)
def crushes(a, b, rate, g):
    n = rng.poisson((b - a) * rate)
    for tc in rng.uniform(a, b, n):
        d = tt(rng.uniform(.08, .22)); x = bp(rng.standard_normal(len(d)), 250, 4200) * np.exp(-d / 0.04)
        x += 0.7 * np.sin(2 * np.pi * rng.uniform(60, 110) * d) * np.exp(-d / 0.05)
        place(sfx, x, tc, g * rng.uniform(.5, 1), pan=rng.uniform(-.5, .5))
crushes(0.8, 5.3, 6, .5); crushes(5.3, 12.2, 13, .75); crushes(12.2, 19.8, 8, .5); crushes(19.8, 25.2, 3, .3); crushes(34.6, 42, 10, .6)
# hydraulics: pressure build 13.66-16.56, release, shove 2
a, b = 13.66, 16.56
fs = 900 + 1700 * sm(t, a, b)
hy = bp(rng.standard_normal(N), 700, 3200) * win(a, b, .3, .15) * 0.6
whine = np.sin(2 * np.pi * np.cumsum(380 + 720 * sm(t, a, b)) / SR) * win(a, b, .3, .15) * 0.25
sfx += (hy + whine)[:, None] * 0.6
x = hp(rng.standard_normal(int(.6 * SR)), 2200) * np.exp(-tt(.6) / 0.18); place(sfx, x, 16.6, 0.5)
sfx += (bp(rng.standard_normal(N), 600, 2400) * win(35.0, 41.8, .8, .8) * 0.25 + 0.0)[:, None] * 0.6
# conveyor: rumble + roller clatter + cleat thumps
cv = lp(rng.standard_normal(N), 260) * 4
cl = np.zeros(N)
for tc in np.arange(19.9, 42, 1 / 14):
    i = int((tc + rng.normal(0, .004)) * SR)
    if 0 <= i < N - 400: cl[i:i + 400] += bp(rng.standard_normal(400), 900, 2200) * np.exp(-np.arange(400) / 90)
for tc in np.arange(19.9, 42, 1.0):
    d = tt(.25); place(sfx, lp(rng.standard_normal(len(d)), 140) * np.exp(-d / .07) * 3, tc, .35)
cw = 1.0 * win(19.8, 25.4, .6, .6) + 0.4 * win(25.4, 42, 1, 1)
sfx += ((cv * 0.6 + cl * 0.35) * cw)[:, None] * 0.55
# segment erector: servo whines, grab clunk, place thud, final lock
e0, ec = tl['erector']['start'], tl['erector']['cycle']
for i in range(tl['erector']['segments']):
    ts = e0 + i * ec
    d = tt(0.42 * ec)  # rotate whine
    place(sfx, np.sin(2 * np.pi * np.cumsum(300 + 380 * d / d[-1]) / SR) * np.hanning(len(d)) * .20 + bp(rng.standard_normal(len(d)), 800, 2500) * np.hanning(len(d)) * .12, ts + 0.38 * ec, 0.8, pan=-.2)
    d = tt(0.12); place(sfx, bp(rng.standard_normal(len(d)), 300, 2500) * np.exp(-d / .03) + .6 * np.sin(2 * np.pi * 130 * d) * np.exp(-d / .05), ts + 0.30 * ec, .5)
    d = tt(0.5); place(sfx, reverb(np.sin(2 * np.pi * 68 * d) * np.exp(-d / .12) + .5 * bp(rng.standard_normal(len(d)), 900, 3200) * np.exp(-d / .02), 1.0, .3), ts + 0.90 * ec, .9)
d = tt(1.2); place(sfx, reverb(bp(rng.standard_normal(len(d)), 500, 2200) * np.exp(-d / .08) + np.sin(2 * np.pi * 220 * d) * np.exp(-d / .5) * .25, 1.6, .4), e0 + 5 * ec + 0.9 * ec, .7)
# cinematic impacts + risers on every scene cut, opening hit at 0
for k, c in enumerate(cuts[:-1]):
    d = tt(1.8); ph = 2 * np.pi * np.cumsum(30 + 60 * np.exp(-d / 0.18)) / SR
    boom = np.sin(ph) * np.exp(-d / 0.55) + 0.5 * lp(rng.standard_normal(len(d)), 900) * np.exp(-d / .25)
    place(music, reverb(boom, 1.8, .35), c, 1.15 if k == 0 else 0.8)
    if k:
        rd = tt(1.0); rs = bp(rng.standard_normal(len(rd)), 250, 4500, 2) * (rd / rd[-1]) ** 2.5
        place(music, rs, c - 1.0, 0.22)
# ---------------- ducking under the real voiceover ----------------
sr_v, v = wavfile.read('public/audio/voiceover.wav'); v = v.astype(np.float64) / 32768
vr = np.sqrt(np.convolve(v ** 2, np.ones(int(.025 * sr_v)) / (.025 * sr_v), 'same'))
speak = (vr > vr.max() * 0.035).astype(float)
speak = np.interp(t, np.arange(len(v)) / sr_v, speak)
g = np.zeros(N); y = 1.0
aa, ar = 1 - np.exp(-1 / (SR * 0.04)), 1 - np.exp(-1 / (SR * 0.45))
target = 1.0 - 0.80 * speak          # -14 dB while narration is present
# one-pole smoother (fast attack, slow release) vectorised through lfilter on blocks
for i in range(0, N, 441):
    blk = target[i:i + 441]
    for j, tv in enumerate(blk):
        y += (tv - y) * (aa if tv < y else ar); g[i + j] = y
bed = (music * 0.55 + sfx * 0.85) * g[:, None]
# loudness relation to voice: bed RMS under speech ~ -16 dB below voice RMS
mask = speak > .5
vrms = np.sqrt(np.mean(v[np.interp(np.arange(len(v)) / sr_v, t, speak) > .5] ** 2))
brms = np.sqrt(np.mean(bed[mask] ** 2))
bed *= (vrms * 10 ** (-16 / 20)) / brms
bed *= sm(DUR - t, 0, 0.8)[:, None] * 0 + (1 - (1 - sm(DUR - t, 0, 0.8)))[:, None]
pk = np.abs(bed).max()
if pk > 0.9: bed *= 0.9 / pk
wavfile.write('public/audio/bed.wav', SR, (bed * 32767).astype(np.int16))
print('bed peak %.3f  voice rms %.4f  bed rms under speech %.4f (%.1f dB below voice)  gap-rms %.4f' % (
    np.abs(bed).max(), vrms, np.sqrt(np.mean(bed[mask] ** 2)), 20 * np.log10(vrms / np.sqrt(np.mean(bed[mask] ** 2))), np.sqrt(np.mean(bed[~mask] ** 2))))
