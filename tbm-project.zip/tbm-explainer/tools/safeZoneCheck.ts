// Offline check that the subject of every shot stays inside the Shorts safe zone
// (top 12% / right 18% / bottom 22% reserved). Uses the exact camera + projection code the video uses.
// Run:  npm run check:safe
import {cameraAt} from '../src/lib/camera';
import {project, SAFE, V3} from '../src/lib/math3d';
import {zmAt, SCENES, R_HEAD} from '../src/lib/motion';

const ring = (z: number, r: number, n = 24): V3[] => Array.from({length: n}, (_, i) => [r * Math.cos((i / n) * 6.2832), r * Math.sin((i / n) * 6.2832), z]);
type Need = {from: number; to: number; name: string; pts: V3[]; pad?: number};
const NEEDS: Need[] = [
  {from: 0.1, to: 5.3, name: 'cutterhead rim (wide shot)', pts: ring(0, R_HEAD - 0.2)},
  {from: 5.4, to: 9.0, name: 'cutterhead top/bottom', pts: [[0, 5, 0], [0, -5, 0]]},
  {from: 10.3, to: 12.2, name: 'close-up: disc-cutter spoke', pts: [[0, 2.2, 0.2], [0, 4.3, 0.2]]},
  {from: 12.3, to: 12.9, name: 'head + buckets', pts: [[0, 4.8, 0], [0, -4.8, 0]]},
  {from: 14.6, to: 16.6, name: 'thrust cylinders (top/bottom)', pts: [[0, 4.6, -9.2], [0, -4.6, -9.2]]},
  {from: 17.4, to: 19.8, name: 'bucket loading zone', pts: [[0, -3.6, -0.4], [0, -1.4, -0.4]]},
  {from: 20.0, to: 25.3, name: 'belt focus point', pts: []},
  {from: 25.5, to: 34.3, name: 'ring N (full circle)', pts: ring(-11.2, 4.85)},
  {from: 34.5, to: 35.5, name: 'machine mid-section', pts: [[0, 0, -9]]},
  {from: 37.4, to: 41.95, name: 'head front + ring N + tail shield', pts: [[0, 0, 0.3], [0, 4.85, -11.2], [0, -4.85, -11.2], [0, 0, -14.5]]},
];
let bad = 0, n = 0;
for (const nd of NEEDS) {
  let worst = '';
  for (let t = nd.from; t <= nd.to; t += 0.1) {
    const cam = cameraAt(t), zm = zmAt(t);
    const pts = nd.name === 'belt focus point' ? ([[0, -0.55, cam.target[2] - zm]] as V3[]) : nd.pts;
    for (const p of pts) {
      const r = project(cam, [p[0], p[1], p[2] + zm]); n++;
      if (!(r.depth > 0 && r.x >= SAFE.left && r.x <= SAFE.right && r.y >= SAFE.top && r.y <= SAFE.bottom)) {
        bad++; if (!worst) worst = `t=${t.toFixed(2)} -> (${r.x.toFixed(0)}, ${r.y.toFixed(0)})`;
      }
    }
  }
  console.log(`${worst ? 'FAIL' : 'ok  '}  ${nd.name}${worst ? '  first at ' + worst : ''}`);
}
console.log(`\n${n} sample points checked, ${bad} outside safe zone (x <= ${SAFE.right.toFixed(0)}, y ${SAFE.top.toFixed(0)}..${SAFE.bottom.toFixed(0)})`);
process.exit(bad ? 1 : 0);
