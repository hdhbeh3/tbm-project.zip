// Look-dev knobs. I could not preview renders in the authoring environment, so if the first render looks
// too dark / too bright, tweak these numbers and re-render (no other file needs editing).
export const LOOK = {
  exposure: 1.05,       // tone-mapping exposure
  ambient: 0.55,        // hemisphere fill
  key: 1900,            // key spot (candela)
  fill: 320,            // point-light fills
  dolly: 520,           // light that follows the camera target
  fog: 0.0105,          // exponential fog density
  envIntensity: 1.0,    // multiplier on the procedural environment reflections
  captionSize: 58,      // px, subtitle font size
};
