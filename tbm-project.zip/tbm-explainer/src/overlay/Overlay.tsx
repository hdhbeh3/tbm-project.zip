import React from 'react';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import tl from '../data/timeline.json';
import {LOOK} from '../config';
import {D2R, FPS, SCENES, Z_RING_N, ZM_INSTALL, erectorState, headAngle, sstep, win, zmAt} from '../lib/motion';
import {cameraAt} from '../lib/camera';
import {FRAME_H, FRAME_W, SAFE, V3, project} from '../lib/math3d';

const FONT = 'Inter, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Liberation Sans", "DejaVu Sans", sans-serif';
const CAP_BOTTOM = FRAME_H * 0.78 - 20;         // captions end 20px above the bottom-22% clearance zone
const CAP_LEFT = 40, CAP_W = SAFE.right - 40 - 0;  // never into the right-18% zone

// ---------- component call-outs (anchor = machine-local point; labels are small and live inside the safe zone) ----------
interface Label { text: string; t0: number; t1: number; anchor: (t: number) => V3 }
const spokeNear = (t: number, deg: number, r: number, z: number): V3 => {
  const th = headAngle(t); let best = 0, bd = 1e9;
  for (let k = 0; k < 6; k++) { let a = ((th + (k * Math.PI) / 3) / D2R) % 360; if (a < 0) a += 360; const d = Math.abs(((a - deg + 540) % 360) - 180); if (d < bd) { bd = d; best = a; } }
  return [r * Math.cos(best * D2R), r * Math.sin(best * D2R), z];
};
const bucketNear = (t: number, deg: number): V3 => {
  const th = headAngle(t); let best = 0, bd = 1e9;
  for (let k = 0; k < 6; k++) { let a = ((th + (30 + 60 * k) * D2R) / D2R) % 360; if (a < 0) a += 360; const d = Math.abs(((a - deg + 540) % 360) - 180); if (d < bd) { bd = d; best = a; } }
  return [4.5 * Math.cos(best * D2R), 4.5 * Math.sin(best * D2R), -0.6];
};
const LABELS: Label[] = [
  {text: 'ROTATING CUTTERHEAD', t0: 5.7, t1: 8.9, anchor: () => [-3.4, 3.4, 0.3]},
  {text: 'DISC CUTTERS', t0: 9.7, t1: 12.15, anchor: t => spokeNear(t, 100, 3.2, 0.25)},
  {text: 'HYDRAULIC THRUST', t0: 13.8, t1: 17.0, anchor: () => [-0.9, 4.5, -9.0]},
  {text: 'COLLECTION BUCKETS', t0: 17.5, t1: 19.75, anchor: t => bucketNear(t, 250)},
  {text: 'ROCK CONVEYOR', t0: 20.3, t1: 25.3, anchor: t => [0, -0.55, cameraAt(t).target[2] - zmAt(t)]},
  {text: 'SEGMENT ERECTOR', t0: 27.5, t1: 31.6, anchor: t => { const e = erectorState(t); return [3.4 * Math.cos(e.alpha), 3.4 * Math.sin(e.alpha), e.s]; }},
  {text: 'CONCRETE SEGMENTS', t0: 31.9, t1: 34.3, anchor: () => [0, 4.6, Z_RING_N]},
  // scene 6: all seven systems, revealed in the order the narration mentions them
  {text: 'THRUST CYLINDERS', t0: 35.3, t1: 42, anchor: () => [-0.9, 4.5, -9.0]},
  {text: 'CUTTERHEAD', t0: 37.5, t1: 42, anchor: () => [-1.5, 2.5, 0.3]},
  {text: 'DISC CUTTERS', t0: 37.9, t1: 42, anchor: t => spokeNear(t, 160, 3.9, 0.25)},
  {text: 'COLLECTION BUCKETS', t0: 38.7, t1: 42, anchor: t => bucketNear(t, 200)},
  {text: 'ROCK CONVEYOR', t0: 39.0, t1: 42, anchor: () => [0, -0.55, -22]},
  {text: 'SEGMENT ERECTOR', t0: 40.4, t1: 42, anchor: () => [0, 0, -10.4]},
  {text: 'CONCRETE LINING', t0: 40.7, t1: 42, anchor: () => [0, -4.5, -19.2]},
];

const Labels: React.FC<{t: number}> = ({t}) => {
  const cam = cameraAt(t), zm = zmAt(t);
  const items = LABELS.filter(l => t >= l.t0 && t <= l.t1).map(l => {
    const a = Math.min(sstep(t, l.t0, l.t0 + 0.3), 1 - sstep(t, l.t1 - 0.3, l.t1));
    const p = project(cam, (() => { const q = l.anchor(t); return [q[0], q[1], q[2] + zm] as V3; })());
    const w = l.text.length * 17.5 + 44, h = 54;
    const ax = Math.min(SAFE.right - 16, Math.max(24, p.x)), ay = Math.min(1290, Math.max(SAFE.top + 30, p.y));
    let left = ax - 48 - w; if (left < 24) left = ax + 48; if (left + w > SAFE.right - 16) left = SAFE.right - 16 - w;
    return {l, a, ax, ay, w, h, left, top: Math.min(1290 - h, Math.max(SAFE.top + 24, ay - 70))};
  }).sort((x, y) => x.top - y.top);
  for (let i = 1; i < items.length; i++) { const prev = items[i - 1]; if (items[i].top < prev.top + prev.h + 14) items[i].top = prev.top + prev.h + 14; if (items[i].top + items[i].h > 1290) items[i].top = 1290 - items[i].h; }
  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      <svg width={FRAME_W} height={FRAME_H} style={{position: 'absolute', left: 0, top: 0}}>
        {items.map((it, i) => {
          const bx = it.left + (it.left < it.ax ? it.w : 0), by = it.top + it.h / 2;
          return (<g key={i} opacity={it.a}><line x1={bx} y1={by} x2={it.ax} y2={it.ay} stroke="#ffc233" strokeWidth={2.5} /><circle cx={it.ax} cy={it.ay} r={7} fill="none" stroke="#ffc233" strokeWidth={3} /><circle cx={it.ax} cy={it.ay} r={2.5} fill="#ffc233" /></g>);
        })}
      </svg>
      {items.map((it, i) => (
        <div key={i} style={{position: 'absolute', left: it.left, top: it.top, width: it.w, height: it.h, opacity: it.a, boxSizing: 'border-box', padding: '0 14px', display: 'flex', alignItems: 'center', fontFamily: FONT, fontWeight: 700, fontSize: 28, letterSpacing: 2, color: '#f3f1ea', background: 'rgba(10,12,14,0.74)', borderLeft: '5px solid #ffc233', borderRadius: 3, whiteSpace: 'nowrap'}}>{it.l.text}</div>
      ))}
    </AbsoluteFill>
  );
};

const Captions: React.FC<{t: number}> = ({t}) => {
  const c = tl.captions.find(k => t >= k.start - 0.05 && t <= k.end + 0.28);
  if (!c) return null;
  const a = Math.min(sstep(t, c.start - 0.05, c.start + 0.08), 1 - sstep(t, c.end + 0.1, c.end + 0.28));
  const o = '0 0 6px #000, 2px 2px 0 #000, -2px 2px 0 #000, 2px -2px 0 #000, -2px -2px 0 #000, 0 3px 10px rgba(0,0,0,.9)';
  return (
    <div style={{position: 'absolute', left: CAP_LEFT, width: CAP_W, bottom: FRAME_H - CAP_BOTTOM, minHeight: 80, display: 'flex', alignItems: 'flex-end', justifyContent: 'center', textAlign: 'center', opacity: a}}>
      <div style={{fontFamily: FONT, fontWeight: 800, fontSize: LOOK.captionSize, lineHeight: 1.12, color: '#fff', textShadow: o, textTransform: 'uppercase', letterSpacing: 1}}>{c.text}</div>
    </div>
  );
};

export const Overlay: React.FC<{showSafeGuides: boolean}> = ({showSafeGuides}) => {
  const frame = useCurrentFrame(), t = frame / FPS;
  // black dip over every scene cut (hides pop-in, adds a cinematic impact) + opening flash
  let dip = 0; for (let i = 1; i < SCENES.length; i++) dip = Math.max(dip, Math.max(0, 1 - Math.abs(t - SCENES[i].start) / 0.16));
  const flash = 0.35 * (1 - sstep(t, 0, 0.22));
  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      {/* grade: vignette + teal/orange split-tone + subtle grain */}
      <AbsoluteFill style={{background: 'radial-gradient(ellipse at 46% 45%, rgba(0,0,0,0) 52%, rgba(0,0,0,0.58) 100%)'}} />
      <AbsoluteFill style={{background: 'linear-gradient(180deg, rgba(20,70,95,0.20), rgba(130,70,15,0.14))', mixBlendMode: 'soft-light'}} />
      <AbsoluteFill style={{opacity: 0.07, mixBlendMode: 'overlay'}}>
        <svg width="100%" height="100%"><filter id="g"><feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" seed={frame % 97} /></filter><rect width="100%" height="100%" filter="url(#g)" /></svg>
      </AbsoluteFill>
      <Labels t={t} />
      <Captions t={t} />
      <AbsoluteFill style={{background: '#fff', opacity: flash}} />
      <AbsoluteFill style={{background: '#000', opacity: dip * 0.94}} />
      {showSafeGuides && (
        <AbsoluteFill>
          <div style={{position: 'absolute', left: 0, top: 0, width: FRAME_W, height: FRAME_H * 0.12, background: 'rgba(255,0,0,.25)'}} />
          <div style={{position: 'absolute', left: SAFE.right, top: 0, width: FRAME_W - SAFE.right, height: FRAME_H, background: 'rgba(255,0,0,.25)'}} />
          <div style={{position: 'absolute', left: 0, top: SAFE.bottom, width: FRAME_W, height: FRAME_H - SAFE.bottom, background: 'rgba(255,0,0,.25)'}} />
        </AbsoluteFill>
      )}
    </AbsoluteFill>
  );
};
