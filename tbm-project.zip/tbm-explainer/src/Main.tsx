import React from 'react';
import {AbsoluteFill, Audio, staticFile} from 'remotion';
import {Scene3D} from './three/Scene3D';
import {Overlay} from './overlay/Overlay';

export const Main: React.FC<{showSafeGuides?: boolean}> = ({showSafeGuides}) => (
  <AbsoluteFill style={{backgroundColor: '#000'}}>
    <Scene3D />
    <Overlay showSafeGuides={!!showSafeGuides} />
    {/* The supplied narration is the master clock: untouched, full volume. */}
    <Audio src={staticFile('audio/voiceover.wav')} volume={1} />
    {/* Original music + SFX, already ducked under the narration (see tools/make_audio.py). */}
    <Audio src={staticFile('audio/bed.wav')} volume={1} />
  </AbsoluteFill>
);
