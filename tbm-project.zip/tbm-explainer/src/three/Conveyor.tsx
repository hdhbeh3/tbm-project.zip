import React, {useLayoutEffect, useMemo, useRef} from 'react';
import * as THREE from 'three';
import {useCurrentFrame} from 'remotion';
import {BELT_V, BELT_Y, FPS, sstep, win} from '../lib/motion';
import {mats} from '../lib/materials';
import {box} from './geo';

const ZS = -1.9, L = 34, PITCH = 1.0;
const SEGS = 24, SEG_L = 1.42;

export const Conveyor: React.FC = () => {
  const t = useCurrentFrame() / FPS, M = mats();
  const cleats = useRef<THREE.InstancedMesh>(null!), idler = useRef<THREE.InstancedMesh>(null!), sideL = useRef<THREE.InstancedMesh>(null!), sideR = useRef<THREE.InstancedMesh>(null!), path = useRef<THREE.InstancedMesh>(null!);
  const dummy = useMemo(() => new THREE.Object3D(), []);
  const stations = 22;
  const g = useMemo(() => ({idler: new THREE.CylinderGeometry(0.075, 0.075, 0.95, 8), side: new THREE.CylinderGeometry(0.075, 0.075, 0.5, 8), pathMat: new THREE.MeshBasicMaterial({toneMapped: false})}), []);
  useLayoutEffect(() => {
    for (let i = 0; i < L / PITCH; i++) {
      const z = ZS - ((i * PITCH + BELT_V * t) % L);
      dummy.position.set(0, BELT_Y + 0.065, z); dummy.rotation.set(0, 0, 0); dummy.scale.set(1, 1, 1); dummy.updateMatrix(); cleats.current.setMatrixAt(i, dummy.matrix);
    }
    cleats.current.instanceMatrix.needsUpdate = true;
    for (let k = 0; k < stations; k++) {
      const z = -2.6 - 1.5 * k, spin = (BELT_V * t) / 0.08; // roller surface speed = belt speed
      dummy.position.set(0, BELT_Y - 0.13, z); dummy.rotation.set(0, 0, Math.PI / 2); dummy.rotateX(spin); dummy.updateMatrix(); idler.current.setMatrixAt(k, dummy.matrix);
      for (const [ref, sx] of [[sideL, -1], [sideR, 1]] as const) {
        dummy.position.set(sx * 0.78, BELT_Y - 0.06, z); dummy.rotation.set(0, 0, Math.PI / 2 + sx * 0.38); dummy.rotateX(spin); dummy.updateMatrix(); ref.current.setMatrixAt(k, dummy.matrix);
      }
    }
    [idler, sideL, sideR].forEach(r => (r.current.instanceMatrix.needsUpdate = true));
    // yellow conveyor-path highlight: sweeps down the belt in scene 4, stays faintly lit afterwards
    const strength = 0.25 + 0.75 * win(t, 19.84, 25.6, 0.4, 0.6);
    const front = -2.0 - 7 * (t - 19.9);
    const c = new THREE.Color();
    for (let s = 0; s < SEGS * 2; s++) {
      const side = s % 2 ? 1 : -1, idx = (s / 2) | 0, z = -2.2 - idx * SEG_L;
      dummy.position.set(side * 0.99, BELT_Y + 0.2, z); dummy.rotation.set(0, 0, 0); dummy.updateMatrix(); path.current.setMatrixAt(s, dummy.matrix);
      const lit = t < 19.84 ? 0 : Math.max(0, Math.min(1, (z - front) / -3 + 1)) * strength;
      c.setRGB(0.12 + 0.9 * lit, 0.085 + 0.62 * lit, 0.01 + 0.07 * lit); path.current.setColorAt(s, c);
    }
    path.current.instanceMatrix.needsUpdate = true; if (path.current.instanceColor) path.current.instanceColor.needsUpdate = true;
  });
  const legs = [-4.2, -6.2, -14, -18, -22, -26, -30, -34];
  return (
    <group>
      {/* belt: top run, return run, frame rails */}
      <mesh geometry={box(1.5, 0.07, L)} position={[0, BELT_Y, ZS - L / 2]} material={M.rubber} receiveShadow />
      <mesh geometry={box(1.5, 0.05, L)} position={[0, -1.1, ZS - L / 2]} material={M.rubber} />
      <mesh geometry={box(0.12, 0.16, L + 0.4)} position={[-0.9, BELT_Y - 0.05, ZS - L / 2]} material={M.machine} />
      <mesh geometry={box(0.12, 0.16, L + 0.4)} position={[0.9, BELT_Y - 0.05, ZS - L / 2]} material={M.machine} />
      <instancedMesh ref={cleats} args={[box(1.3, 0.05, 0.1), M.steelDark, L / PITCH]} frustumCulled={false} />
      <instancedMesh ref={idler} args={[g.idler, M.steelCyl, stations]} frustumCulled={false} />
      <instancedMesh ref={sideL} args={[g.side, M.steelCyl, stations]} frustumCulled={false} />
      <instancedMesh ref={sideR} args={[g.side, M.steelCyl, stations]} frustumCulled={false} />
      <instancedMesh ref={path} args={[box(0.05, 0.06, SEG_L - 0.08), g.pathMat, SEGS * 2]} frustumCulled={false} />
      {/* head pulley at the hopper end */}
      <mesh position={[0, BELT_Y - 0.5, ZS + 0.1]} rotation={[0, 0, Math.PI / 2]} material={M.steelCyl}><cylinderGeometry args={[0.5, 0.5, 1.5, 20]} /></mesh>
      {legs.map(z => (
        <group key={z}>
          <mesh geometry={box(0.08, 2.9, 0.08)} position={[-0.9, -2.45, z]} material={M.machine} />
          <mesh geometry={box(0.08, 2.9, 0.08)} position={[0.9, -2.45, z]} material={M.machine} />
        </group>
      ))}
    </group>
  );
};

/** Trailing back-up gantries riding inside the finished lining (carry the belt, power and grout equipment). */
export const Gantry: React.FC = () => {
  const M = mats();
  return (
    <group>
      {[-20, -25, -30].map(z => (
        <group key={z} position={[0, 0, z]}>
          {[-3.2, 3.2].map(x => <mesh key={x} geometry={box(0.22, 4.6, 0.22)} position={[x, -0.3, 0]} material={M.machine} />)}
          <mesh geometry={box(6.6, 0.22, 0.3)} position={[0, 2.0, 0]} material={M.machine} />
          <mesh geometry={box(6.6, 0.1, 1.3)} position={[0, -2.5, 0]} material={M.steelDark} />
          <mesh geometry={box(6.6, 0.07, 0.07)} position={[0, 2.25, 0]} material={M.yellow} />
          <mesh geometry={box(0.5, 0.2, 0.3)} position={[-2.2, 1.78, 0]} material={M.lamp} />
          <mesh geometry={box(0.5, 0.2, 0.3)} position={[2.2, 1.78, 0]} material={M.lamp} />
        </group>
      ))}
      {[-3.2, 3.2].map(x => <mesh key={x} geometry={box(0.14, 0.14, 10.5)} position={[x, -0.5, -25]} material={M.machine} />)}
      {[-3.2, 3.2].map(x => <mesh key={'y' + x} geometry={box(0.06, 0.06, 10.5)} position={[x, 0.3, -25]} material={M.yellow} />)}
    </group>
  );
};
