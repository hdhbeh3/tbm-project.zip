import React, {useLayoutEffect, useMemo, useRef} from 'react';
import * as THREE from 'three';
import {useCurrentFrame} from 'remotion';
import {D2R, R_SEG_IN, R_SEG_OUT, RING_LEN, SEGS, faceOn} from '../lib/motion';
import {hash01} from '../lib/rand';
import {mats} from '../lib/materials';
import {box, segmentGeo} from './geo';

const K = 26; // finished rings behind the machine (world z: ring k centre = -11.2 - 1.6 k)
const STD = SEGS.filter(s => s.w === 64), KEY = SEGS[5];

/** Completed precast lining (instanced, world space) with rails, sleepers, service pipes and crown lamps. */
export const Lining: React.FC = () => {
  const M = mats();
  const stdRef = useRef<THREE.InstancedMesh>(null!), keyRef = useRef<THREE.InstancedMesh>(null!), sleep = useRef<THREE.InstancedMesh>(null!), lamps = useRef<THREE.InstancedMesh>(null!);
  const d = useMemo(() => new THREE.Object3D(), []);
  const g = useMemo(() => ({std: segmentGeo(R_SEG_IN, R_SEG_OUT, 63.5, RING_LEN - 0.06), key: segmentGeo(R_SEG_IN, R_SEG_OUT, 39.5, RING_LEN - 0.06)}), []);
  useLayoutEffect(() => {
    const c = new THREE.Color();
    for (let k = 0; k < K; k++) {
      const z = -11.2 - 1.6 * k, rot = ((k + 1) % 2) * 32 * D2R;
      STD.forEach((s, j) => {
        d.position.set(0, 0, z); d.rotation.set(0, 0, rot + s.angle * D2R); d.scale.set(1, 1, 1); d.updateMatrix();
        stdRef.current.setMatrixAt(k * 5 + j, d.matrix); const v = 0.86 + hash01(k * 9 + j) * 0.22; c.setRGB(v, v, v); stdRef.current.setColorAt(k * 5 + j, c);
      });
      d.rotation.set(0, 0, rot + KEY.angle * D2R); d.updateMatrix(); keyRef.current.setMatrixAt(k, d.matrix);
    }
    for (let i = 0; i < 58; i++) { d.position.set(0, -4.02, -12.2 - i); d.rotation.set(0, 0, 0); d.updateMatrix(); sleep.current.setMatrixAt(i, d.matrix); }
    for (let i = 0; i < 10; i++) { d.position.set(0, 4.12, -16 - i * 6); d.updateMatrix(); lamps.current.setMatrixAt(i, d.matrix); }
    [stdRef, keyRef, sleep, lamps].forEach(r => (r.current.instanceMatrix.needsUpdate = true)); if (stdRef.current.instanceColor) stdRef.current.instanceColor.needsUpdate = true;
  }, []);
  return (
    <group>
      <instancedMesh ref={stdRef} args={[g.std, M.concrete, K * 5]} frustumCulled={false} receiveShadow />
      <instancedMesh ref={keyRef} args={[g.key, M.concrete, K]} frustumCulled={false} receiveShadow />
      <instancedMesh ref={sleep} args={[box(2.6, 0.1, 0.25), M.steelDark, 58]} frustumCulled={false} />
      <instancedMesh ref={lamps} args={[box(0.7, 0.14, 0.3), M.lamp, 10]} frustumCulled={false} />
      {[-0.75, 0.75].map(x => <mesh key={x} geometry={box(0.09, 0.14, 62)} position={[x, -3.93, -43]} material={M.steelCyl} />)}
      <mesh geometry={box(0.24, 0.24, 62)} position={[-3.55, 2.1, -43]} material={M.yellow} />
      <mesh geometry={box(0.34, 0.1, 62)} position={[-3.9, 0.9, -43]} material={M.steelDark} />
      <mesh position={[-3.3, 2.7, -43]} rotation={[Math.PI / 2, 0, 0]} material={M.machine}><cylinderGeometry args={[0.12, 0.12, 62, 10]} /></mesh>
    </group>
  );
};
