import React from 'react';
import {mats} from '../lib/materials';
import {D2R, R_SHIELD, R_SHIELD_IN} from '../lib/motion';
import {box, cylZ, ringGeo} from './geo';

const Torus: React.FC<{z: number; r?: number}> = ({z, r = 4.88}) => (
  <mesh position={[0, 0, z]} material={mats().machineC}><torusGeometry args={[r, 0.09, 8, 72]} /></mesh>
);

/** Shield skins (cutaway), pressure bulkhead, main-drive motors, muck chute + hopper, platforms. */
export const Shell: React.FC = () => {
  const M = mats();
  const chuteA = Math.atan2(0.975, -0.22);
  return (
    <group>
      {/* shield sections */}
      <mesh geometry={cylZ(R_SHIELD, 5.0, 80, true)} position={[0, 0, -3.7]} material={M.shell} castShadow receiveShadow />
      <mesh geometry={cylZ(5.14, 0.28, 80, true)} position={[0, 0, -1.55]} material={M.yellowShell} />
      <mesh geometry={cylZ(5.14, 0.28, 80, true)} position={[0, 0, -5.85]} material={M.yellowShell} />
      <mesh geometry={cylZ(5.16, 0.4, 80, true)} position={[0, 0, -6.4]} material={M.steelDarkC} />
      <mesh geometry={cylZ(5.08, 3.1, 80, true)} position={[0, 0, -8.15]} material={M.shell} receiveShadow />
      <mesh geometry={cylZ(5.06, 4.95, 80, true)} position={[0, 0, -12.325]} material={M.shell} receiveShadow />
      <mesh geometry={cylZ(5.1, 0.3, 80, true)} position={[0, 0, -14.65]} material={M.rubberC} />
      <mesh geometry={cylZ(5.12, 0.22, 80, true)} position={[0, 0, -10.0]} material={M.yellowShell} />
      {/* structural ribs inside the shield */}
      {[-2.4, -3.9, -5.2, -7.2, -9.0, -10.6, -12.2, -13.8].map(z => <Torus key={z} z={z} />)}
      {/* pressure bulkhead behind the cutterhead (annulus around the muck opening) */}
      <mesh geometry={ringGeo(1.0, R_SHIELD_IN, 0.32, 72)} position={[0, 0, -2.9]} material={M.steelDarkC} receiveShadow />
      {/* main bearing housing + drive motors (left half, so the cutaway shows them) */}
      <mesh geometry={cylZ(1.9, 1.4, 40)} position={[0, 0, -3.6]} material={M.steelDark} />
      {[90, 135, 180, 225, 270].map(a => (
        <group key={a} position={[3.0 * Math.cos(a * D2R), 3.0 * Math.sin(a * D2R), -4.0]}>
          <mesh geometry={cylZ(0.55, 1.5, 28)} material={M.machine} castShadow />
          <mesh geometry={cylZ(0.58, 0.28, 28)} position={[0, 0, -0.85]} material={M.yellow} />
          <mesh geometry={box(0.5, 0.5, 0.5)} position={[0, 0, 0.9]} material={M.steelDark} />
        </group>
      ))}
      {/* muck chute (catches rock from the buckets) and hopper above the conveyor */}
      <group position={[0, 2.22, -1.8]} rotation={[chuteA, 0, 0]}>
        <mesh geometry={box(1.8, 0.08, 3.7)} material={M.steelDark} />
        <mesh geometry={box(0.08, 0.5, 3.7)} position={[0.95, 0.24, 0]} material={M.machine} />
        <mesh geometry={box(0.08, 0.5, 3.7)} position={[-0.95, 0.24, 0]} material={M.machine} />
      </group>
      <group position={[0, -0.05, -2.3]}>
        <mesh geometry={box(0.08, 1.3, 1.1)} position={[0.98, 0, 0]} material={M.machine} />
        <mesh geometry={box(0.08, 1.3, 1.1)} position={[-0.98, 0, 0]} material={M.machine} />
        <mesh geometry={box(2.0, 1.3, 0.08)} position={[0, 0, -0.58]} material={M.machine} />
      </group>
      {/* work platform + yellow handrail in the front shield */}
      <mesh geometry={box(4.4, 0.12, 2.6)} position={[0, -2.6, -4.4]} material={M.machine} />
      <mesh geometry={box(0.05, 0.9, 2.6)} position={[2.2, -2.1, -4.4]} material={M.yellow} />
      <mesh geometry={box(0.05, 0.9, 2.6)} position={[-2.2, -2.1, -4.4]} material={M.yellow} />
    </group>
  );
};
