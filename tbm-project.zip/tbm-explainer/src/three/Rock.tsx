import React, {useMemo} from 'react';
import * as THREE from 'three';
import {useCurrentFrame} from 'remotion';
import {FACE_Z, FPS, faceOn, R_BORE} from '../lib/motion';
import {mats} from '../lib/materials';
import {faceTexture, repeated, rockHeight, rockSection} from '../lib/textures';
import {fbm3} from '../lib/rand';
import {KERF_RADII} from './Cutterhead';

/** Rough rock bore wall (world space, static). Clipped by the cutaway plane; hidden ahead of the rock face. */
export const BoreWall: React.FC = () => {
  const geo = useMemo(() => {
    const g = new THREE.CylinderGeometry(R_BORE, R_BORE, 170, 96, 170, true); g.rotateX(Math.PI / 2); g.translate(0, 0, -10);
    const p = g.attributes.position;
    for (let i = 0; i < p.count; i++) {
      const x = p.getX(i), y = p.getY(i), z = p.getZ(i), a = Math.atan2(y, x);
      const n = fbm3(Math.cos(a) * 2.4, Math.sin(a) * 2.4, z * 0.33, 4, 5) - 0.5, r = R_BORE + n * 0.55;
      p.setXYZ(i, Math.cos(a) * r, Math.sin(a) * r, z);
    }
    g.computeVertexNormals(); return g;
  }, []);
  return <mesh geometry={geo} material={mats().bore} receiveShadow />;
};

/** Rock section caps — make the cutaway read as solid mountain, not hollow shell. */
const Cap: React.FC<{z0: number; z1: number; y0: number; y1: number}> = ({z0, z1, y0, y1}) => {
  const {geo, mat} = useMemo(() => {
    const g = new THREE.PlaneGeometry(z1 - z0, y1 - y0); g.rotateY(Math.PI / 2); g.translate(0.0, (y0 + y1) / 2, (z0 + z1) / 2);
    const m = mats().section.clone(); m.map = repeated(rockSection(), (z1 - z0) / 7, (y1 - y0) / 7); m.bumpMap = repeated(rockHeight(), (z1 - z0) / 7, (y1 - y0) / 7, false);
    return {geo: g, mat: m};
  }, [z0, z1, y0, y1]);
  return <mesh geometry={geo} material={mat} receiveShadow />;
};
export const WorldCaps: React.FC = () => {
  const t = useCurrentFrame() / FPS;
  if (!faceOn(t)) return null;
  return (<group><Cap z0={-95} z1={75} y0={R_BORE} y1={20} /><Cap z0={-95} z1={75} y0={-20} y1={-R_BORE} /></group>);
};

/** Rock face attached to the machine: kerf grooves cut by each disc-cutter ring + fractures. Plus the solid rock ahead in section. */
export const RockFace: React.FC = () => {
  const t = useCurrentFrame() / FPS;
  const {geo, mat} = useMemo(() => {
    const g = new THREE.RingGeometry(0.001, 5.3, 128, 72);
    const p = g.attributes.position;
    for (let i = 0; i < p.count; i++) {
      const x = p.getX(i), y = p.getY(i), r = Math.hypot(x, y); let kerf = 0;
      for (const rr of KERF_RADII) kerf = Math.max(kerf, Math.exp(-Math.pow((r - rr) / 0.07, 2)));
      p.setZ(i, -(0.085 * kerf + (fbm3(x * 0.8, y * 0.8, 1.7, 4, 41) - 0.5) * 0.22));
    }
    g.rotateY(Math.PI); g.computeVertexNormals();
    const m = mats().face.clone(); m.map = faceTexture(KERF_RADII, 5.3); m.bumpMap = rockHeight(); m.bumpScale = 2;
    return {geo: g, mat: m};
  }, []);
  const capA = useMemo(() => { const g = new THREE.PlaneGeometry(60, 2 * R_BORE); g.rotateY(Math.PI / 2); g.translate(0.001, 0, FACE_Z + 30); return g; }, []);
  const capMat = useMemo(() => { const m = mats().section.clone(); m.map = repeated(rockSection(), 9, 1.6); m.bumpMap = repeated(rockHeight(), 9, 1.6, false); return m; }, []);
  if (!faceOn(t)) return null;
  return (
    <group>
      <mesh geometry={geo} material={mat} position={[0, 0, FACE_Z]} receiveShadow />
      <mesh geometry={capA} material={capMat} receiveShadow />
    </group>
  );
};

export const Backdrop: React.FC = () => (<mesh material={mats().backdrop}><sphereGeometry args={[160, 28, 18]} /></mesh>);
