import * as THREE from 'three';
import {D2R} from '../lib/motion';

const cache = new Map<string, THREE.BufferGeometry>();
const memo = (k: string, f: () => THREE.BufferGeometry) => { let g = cache.get(k); if (!g) { g = f(); cache.set(k, g); } return g; };

/** flat annulus extruded along z, centred on z=0 */
export const ringGeo = (inner: number, outer: number, depth: number, seg = 64) => memo(`ring${inner}_${outer}_${depth}`, () => {
  const s = new THREE.Shape(); s.absarc(0, 0, outer, 0, Math.PI * 2, false);
  const h = new THREE.Path(); h.absarc(0, 0, inner, 0, Math.PI * 2, true); s.holes.push(h);
  const g = new THREE.ExtrudeGeometry(s, {depth, bevelEnabled: false, curveSegments: seg}); g.translate(0, 0, -depth / 2); return g;
});
/** tunnel-lining segment: annular sector centred on angle 0, width wDeg, extruded along z */
export const segmentGeo = (rIn: number, rOut: number, wDeg: number, depth: number) => memo(`seg${rIn}_${rOut}_${wDeg}_${depth}`, () => {
  const a = (wDeg * D2R) / 2, s = new THREE.Shape();
  s.moveTo(rIn * Math.cos(-a), rIn * Math.sin(-a)); s.absarc(0, 0, rOut, -a, a, false);
  s.lineTo(rIn * Math.cos(a), rIn * Math.sin(a)); s.absarc(0, 0, rIn, a, -a, true); s.closePath();
  const g = new THREE.ExtrudeGeometry(s, {depth, bevelEnabled: true, bevelThickness: 0.025, bevelSize: 0.025, bevelSegments: 1, curveSegments: 14});
  g.translate(0, 0, -depth / 2); g.computeVertexNormals(); return g;
});
/** cutterhead face plate: disc with six muck openings between the spokes */
export const facePlateGeo = () => memo('face', () => {
  const s = new THREE.Shape(); s.absarc(0, 0, 5.2, 0, Math.PI * 2, false);
  for (let k = 0; k < 6; k++) {
    const c = (30 + 60 * k) * D2R, w = 17 * D2R, h = new THREE.Path();
    h.moveTo(2.0 * Math.cos(c - w), 2.0 * Math.sin(c - w)); h.absarc(0, 0, 2.0, c - w, c + w, false);
    h.lineTo(4.95 * Math.cos(c + w), 4.95 * Math.sin(c + w)); h.absarc(0, 0, 4.95, c + w, c - w, true); h.closePath(); s.holes.push(h);
  }
  const g = new THREE.ExtrudeGeometry(s, {depth: 0.5, bevelEnabled: false, curveSegments: 48}); g.translate(0, 0, -0.5); return g;
});
export const cylZ = (r: number, len: number, seg = 32, open = false) => memo(`cylz${r}_${len}_${seg}_${open}`, () => { const g = new THREE.CylinderGeometry(r, r, len, seg, 1, open); g.rotateX(Math.PI / 2); return g; });
export const box = (x: number, y: number, z: number) => memo(`box${x}_${y}_${z}`, () => new THREE.BoxGeometry(x, y, z));
