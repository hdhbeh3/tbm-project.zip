import React, {useLayoutEffect, useMemo, useRef} from 'react';
import * as THREE from 'three';
import {useCurrentFrame} from 'remotion';
import {D2R, FPS, headAngle, sstep, win} from '../lib/motion';
import {mats} from '../lib/materials';
import {box, cylZ, facePlateGeo, ringGeo} from './geo';

// 36 disc cutters on six spokes + 12 gauge cutters on the rim = 48 hardened-steel discs
export const CUTTERS: {r: number; a: number; gauge: boolean}[] = [];
for (let k = 0; k < 6; k++) for (let j = 0; j < 6; j++) CUTTERS.push({r: 2.0 + 0.55 * j, a: k * 60 * D2R, gauge: false});
for (let i = 0; i < 12; i++) CUTTERS.push({r: 5.12, a: (15 + 30 * i) * D2R, gauge: true});
export const KERF_RADII = [2.0, 2.55, 3.1, 3.65, 4.2, 4.75, 5.12];
const DISC_R = 0.3;

const _d = new THREE.Object3D();
const _m = new THREE.Matrix4(), _a = new THREE.Matrix4(), _b = new THREE.Matrix4();
const T = (x: number, y: number, z: number) => new THREE.Matrix4().makeTranslation(x, y, z);

export function highlightAmt(t: number) { return Math.max(0.18 * sstep(t, 5.6, 6.5), win(t, 6.0, 12.4, 1.2, 0.8)) * 0.9 + 0.35 * win(t, 37.4, 42, 0.6, 0.5); }

export const Cutterhead: React.FC = () => {
  const frame = useCurrentFrame(); const t = frame / FPS; const M = mats();
  const theta = headAngle(t), hl = highlightAmt(t);
  const disc = useRef<THREE.InstancedMesh>(null!), edge = useRef<THREE.InstancedMesh>(null!), hub = useRef<THREE.InstancedMesh>(null!),
    mark = useRef<THREE.InstancedMesh>(null!), hsg = useRef<THREE.InstancedMesh>(null!);
  const discGeo = useMemo(() => new THREE.CylinderGeometry(0.27, 0.27, 0.07, 18), []);
  const edgeGeo = useMemo(() => new THREE.CylinderGeometry(DISC_R, 0.285, 0.035, 26), []);
  const hubGeo = useMemo(() => new THREE.CylinderGeometry(0.12, 0.12, 0.2, 12), []);
  useLayoutEffect(() => {
    M.discEdge.emissiveIntensity = hl;
    CUTTERS.forEach((c, i) => {
      const gaugeTilt = c.gauge ? 0.45 : 0;
      const base = _a.makeRotationZ(c.a).setPosition(c.r * Math.cos(c.a), c.r * Math.sin(c.a), 0);
      const withTilt = _b.copy(base).multiply(_m.makeRotationY(-gaugeTilt));
      const spin = -(theta * c.r) / DISC_R;
      const frameM = withTilt.clone().multiply(T(0, 0, -0.05)).multiply(_m.makeRotationX(spin));
      const discM = frameM.clone().multiply(new THREE.Matrix4().makeRotationZ(Math.PI / 2));
      disc.current.setMatrixAt(i, discM); edge.current.setMatrixAt(i, discM); hub.current.setMatrixAt(i, discM);
      for (let s = 0; s < 2; s++) mark.current.setMatrixAt(i * 2 + s, frameM.clone().multiply(T(s ? 0.045 : -0.045, 0.2, 0)));
      for (let s = 0; s < 2; s++) hsg.current.setMatrixAt(i * 2 + s, withTilt.clone().multiply(T(0, s ? 0.155 : -0.155, -0.14)));
    });
    [disc, edge, hub, mark, hsg].forEach(r => (r.current.instanceMatrix.needsUpdate = true));
  });
  const buckets = useMemo(() => [0, 1, 2, 3, 4, 5].map(k => (30 + 60 * k) * D2R), []);
  return (
    <group rotation={[0, 0, theta]}>
      {/* face plate with muck openings, rear plate, rim skirt */}
      <mesh geometry={facePlateGeo()} material={M.steelDark} castShadow receiveShadow />
      <mesh geometry={cylZ(4.9, 0.12, 48)} position={[0, 0, -0.62]} material={M.steelDark} />
      <mesh geometry={cylZ(5.25, 1.15, 96, true)} position={[0, 0, -0.62]} material={M.machine} castShadow />
      <mesh geometry={ringGeo(5.0, 5.27, 0.22, 96)} position={[0, 0, -0.12]} material={M.steelDark} />
      {/* hub, nose cone, drive shaft */}
      <mesh geometry={cylZ(1.7, 1.2, 40)} position={[0, 0, -0.25]} material={M.steelDark} castShadow />
      <mesh position={[0, 0, 0.35]} rotation={[Math.PI / 2, 0, 0]} material={M.machine}><coneGeometry args={[1.5, 0.75, 32]} /></mesh>
      <mesh geometry={cylZ(1.25, 2.4, 32)} position={[0, 0, -2.2]} material={M.steelCyl} />
      <mesh geometry={ringGeo(2.4, 3.1, 0.3, 64)} position={[0, 0, -1.45]} material={M.steelDark} />
      {/* spokes' structural ribs on the back */}
      {[0, 1, 2, 3, 4, 5].map(k => (
        <mesh key={k} geometry={box(3.4, 0.22, 0.5)} position={[Math.cos(k * 60 * D2R) * 3.4, Math.sin(k * 60 * D2R) * 3.4, -0.85]} rotation={[0, 0, k * 60 * D2R]} material={M.machine} />
      ))}
      {/* collection buckets (scoops) at the six rim openings */}
      {buckets.map((a, k) => (
        <group key={k} rotation={[0, 0, a]}>
          <group position={[4.58, 0, -0.62]}>
            <mesh geometry={box(0.1, 2.1, 1.05)} position={[-0.42, 0, 0]} material={M.machine} />
            <mesh geometry={box(0.9, 0.1, 1.05)} position={[0, -1.0, 0]} material={M.machine} />
            <mesh geometry={box(0.9, 0.1, 0.6)} position={[0, 1.0, -0.2]} rotation={[0, 0, -0.35]} material={M.yellow} />
            <mesh geometry={box(0.95, 2.1, 0.08)} position={[0, 0, -0.55]} material={M.steelDark} />
          </group>
        </group>
      ))}
      {/* disc cutters */}
      <instancedMesh ref={hsg} args={[box(0.46, 0.1, 0.42), M.steelDark, CUTTERS.length * 2]} frustumCulled={false} castShadow />
      <instancedMesh ref={disc} args={[discGeo, M.steelPolish, CUTTERS.length]} frustumCulled={false} castShadow />
      <instancedMesh ref={edge} args={[edgeGeo, M.discEdge, CUTTERS.length]} frustumCulled={false} />
      <instancedMesh ref={hub} args={[hubGeo, M.steelDark, CUTTERS.length]} frustumCulled={false} />
      <instancedMesh ref={mark} args={[box(0.02, 0.07, 0.07), M.steelDark, CUTTERS.length * 2]} frustumCulled={false} />
    </group>
  );
};
