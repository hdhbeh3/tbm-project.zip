import React, {useLayoutEffect, useMemo, useRef} from 'react';
import * as THREE from 'three';
import {useCurrentFrame} from 'remotion';
import {BELT_V, BELT_Y, D2R, FPS, cuttingAmt, faceOn, headAngle, smooth, thetaInv} from '../lib/motion';
import {hash01} from '../lib/rand';
import {mats} from '../lib/materials';

const NB = 6, NM = 5, TAU = Math.PI * 2;
const OFF = (b: number) => (30 + 60 * b) * D2R;
const lerp = (a: number, b: number, x: number) => a + (b - a) * x;
const TLAND = 1.55; // seconds from bucket discharge until the rock sits on the belt

/** rock lifted by a bucket (head frame), discharged at the top onto the chute, slid to the hopper, dropped on the belt and carried rearward */
function travel(age: number, b: number, m: number, n: number): [number, number, number] | null {
  const r = (k: number) => hash01(b * 131 + m * 17 + n * 7 + k);
  const xo = (r(1) - 0.5) * 1.0;
  const P0 = [xo * 0.5, 4.45, -0.6], Pc = [xo * 0.5, 3.75, -1.45], Ph = [xo * 0.45, 0.45, -2.25], Pb = [xo * 0.6, BELT_Y + 0.2, -2.4 - r(2) * 0.5];
  if (age < 0) return null;
  const mix = (A: number[], B: number[], s: number, e = 1): [number, number, number] => [lerp(A[0], B[0], s), lerp(A[1], B[1], Math.pow(s, e)), lerp(A[2], B[2], s)];
  if (age < 0.45) return mix(P0, Pc, age / 0.45, 2);
  if (age < 1.35) return mix(Pc, Ph, Math.pow((age - 0.45) / 0.9, 1.6));
  if (age < TLAND) return mix(Ph, Pb, (age - 1.35) / 0.2, 2);
  const z = Pb[2] - BELT_V * (age - TLAND);
  return z < -35.2 ? null : [Pb[0], Pb[1], z];
}

export const Muck: React.FC = () => {
  const t = useCurrentFrame() / FPS, M = mats();
  const carry = useRef<THREE.InstancedMesh>(null!), belt = useRef<THREE.InstancedMesh>(null!), chips = useRef<THREE.InstancedMesh>(null!);
  const g = useMemo(() => ({rock: new THREE.IcosahedronGeometry(0.2, 0), chip: new THREE.IcosahedronGeometry(0.09, 0)}), []);
  const d = useMemo(() => new THREE.Object3D(), []);
  const NC = 220;
  useLayoutEffect(() => {
    const theta = headAngle(t);
    let ic = 0, it = 0;
    const hide = (mesh: THREE.InstancedMesh, i: number) => { d.position.set(0, -100, 0); d.scale.setScalar(0.0001); d.updateMatrix(); mesh.setMatrixAt(i, d.matrix); };
    for (let b = 0; b < NB; b++) {
      const phi = theta + OFF(b), cyc = ((((phi + Math.PI / 2) % TAU) + TAU) % TAU) / TAU;
      const nEv = Math.floor((phi - Math.PI / 2) / TAU), thStar = Math.PI / 2 - OFF(b) + TAU * nEv, age = t - thetaInv(thStar);
      for (let m = 0; m < NM; m++) {
        const rr = (k: number) => hash01(b * 57 + m * 13 + k);
        // carried in the bucket
        if (faceOn(t) && cyc > 0.03 && cyc < 0.5) {
          const s = smooth((cyc - 0.03) / 0.1), rad = 4.4 + rr(1) * 0.3, tan = (m - 2) * 0.28 + (rr(2) - 0.5) * 0.12;
          d.position.set(rad * Math.cos(phi) - tan * Math.sin(phi), rad * Math.sin(phi) + tan * Math.cos(phi), -0.5 - rr(3) * 0.3);
          d.rotation.set(rr(4) * 6, rr(5) * 6, rr(6) * 6); d.scale.set(s * (0.7 + rr(7) * 0.7), s * (0.7 + rr(8) * 0.6), s * (0.7 + rr(9) * 0.6));
          d.updateMatrix(); carry.current.setMatrixAt(ic++, d.matrix);
        } else hide(carry.current, ic++);
        // travelling to / on the belt (latest discharge event of this bucket)
        const p = travel(age, b, m, nEv);
        if (p && t - age > 2.5) {
          d.position.set(p[0], p[1], p[2]); d.rotation.set(age * (1 + rr(1)), age * (0.7 + rr(2)), rr(3) * 6);
          const sc = 0.7 + rr(7) * 0.7; d.scale.set(sc, sc * (0.7 + rr(8) * 0.5), sc); d.updateMatrix(); belt.current.setMatrixAt(it++, d.matrix);
        } else hide(belt.current, it++);
      }
    }
    carry.current.instanceMatrix.needsUpdate = true; belt.current.instanceMatrix.needsUpdate = true;
    // rock chips thrown from the disc cutters touching the face (left half, where the rock section is visible)
    const amt = cuttingAmt(t);
    for (let i = 0; i < NC; i++) {
      const life = 0.9, a = (t * 1.0 + hash01(i * 3.1) * life) % life, tb = t - a;
      if (!(faceOn(t) && amt > 0.12)) { hide(chips.current, i); continue; }
      const thb = headAngle(tb), cand: number[] = [];
      for (let k = 0; k < 6; k++) { const s = (((thb + k * Math.PI / 3) % TAU) + TAU) % TAU; if (s > Math.PI / 2 - 0.1 && s < 1.5 * Math.PI + 0.1) cand.push(s); }
      const s = cand[i % cand.length], ra = 2.0 + 0.55 * ((i * 5) % 6);
      const px = ra * Math.cos(s), py = ra * Math.sin(s);
      const h = (k: number) => hash01(i * 11 + k + Math.floor(tb * 3));
      const vx = -Math.sin(s) * 0.55 * ra * 0.5 + (h(1) - 0.5) * 2.4, vy = Math.cos(s) * 0.55 * ra * 0.5 + (h(2) - 0.5) * 2.4, vz = 1.5 + h(3) * 3.2;
      d.position.set(px + vx * a, py + vy * a - 3.0 * a * a, 0.35 + vz * a);
      d.rotation.set(a * 9 * h(4), a * 7 * h(5), 0); const sc = (0.6 + h(6) * 1.0) * (1 - a / life * 0.6) * amt; d.scale.setScalar(sc); d.updateMatrix(); chips.current.setMatrixAt(i, d.matrix);
    }
    chips.current.instanceMatrix.needsUpdate = true;
  });
  return (
    <group>
      <instancedMesh ref={carry} args={[g.rock, M.rock, NB * NM]} frustumCulled={false} castShadow />
      <instancedMesh ref={belt} args={[g.rock, M.rock, NB * NM]} frustumCulled={false} castShadow />
      <instancedMesh ref={chips} args={[g.chip, M.chip, NC]} frustumCulled={false} />
    </group>
  );
};
