import React, {useLayoutEffect} from 'react';
import * as THREE from 'three';
import {ThreeCanvas} from '@remotion/three';
import {useCurrentFrame} from 'remotion';
import {useThree} from '@react-three/fiber';
import {RoomEnvironment} from 'three/examples/jsm/environments/RoomEnvironment.js';
import {LOOK} from '../config';
import {FACE_Z, FPS, clamp, cutC, faceOn, heroCutC, win, zmAt} from '../lib/motion';
import {cameraAt} from '../lib/camera';
import {FRAME_H, FRAME_W, SHIFT, camUp, norm, sub} from '../lib/math3d';
import {cutPlane, facePlane, heroPlane, mats} from '../lib/materials';
import {Cutterhead} from './Cutterhead';
import {Shell} from './Shell';
import {Thrust} from './Thrust';
import {Conveyor, Gantry} from './Conveyor';
import {Muck} from './Muck';
import {Erector, HeroRing} from './Erector';
import {Lining} from './Lining';
import {BoreWall, Backdrop, RockFace, WorldCaps} from './Rock';
import {BoreLamps, Dust, FaceDust} from './Atmosphere';

const CameraRig: React.FC = () => {
  const {camera, invalidate} = useThree();
  const t = useCurrentFrame() / FPS;
  useLayoutEffect(() => {
    const c = cameraAt(t), cam = camera as THREE.PerspectiveCamera;
    cam.position.set(...c.pos);
    const up = camUp(c); cam.up.set(up[0], up[1], up[2]);
    cam.lookAt(c.target[0], c.target[1], c.target[2]);
    cam.fov = c.fov; cam.aspect = FRAME_W / FRAME_H;
    // shift the principal point so the shot's subject sits in the centre of the YouTube-Shorts safe zone
    cam.setViewOffset(FRAME_W, FRAME_H, SHIFT.x, SHIFT.y, FRAME_W, FRAME_H);
    cam.updateProjectionMatrix(); cam.updateMatrixWorld(); invalidate();
  });
  return null;
};

const Environment: React.FC = () => {
  const {gl, scene} = useThree();
  useLayoutEffect(() => {
    const pm = new THREE.PMREMGenerator(gl); const env = new RoomEnvironment();
    const rt = pm.fromScene(env, 0.04); scene.environment = rt.texture;
    return () => { rt.dispose(); pm.dispose(); };
  }, [gl, scene]);
  return null;
};

const Content: React.FC = () => {
  const t = useCurrentFrame() / FPS, zm = zmAt(t), cam = cameraAt(t);
  cutPlane.constant = cutC(t); heroPlane.constant = heroCutC(t); facePlane.constant = faceOn(t) ? zm + FACE_Z : 99;
  const dollyZ = clamp(cam.target[2], -48, 4);
  const intro = 0.55 + 0.45 * win(t, 0, 1, 0.25, 0.01);   // opening light "kick" in the first second
  return (
    <>
      <color attach="background" args={['#0d0b09']} />
      <fogExp2 attach="fog" args={['#15110d', LOOK.fog]} />
      <CameraRig />
      <Environment />
      <hemisphereLight args={['#aab4c2', '#2a2118', LOOK.ambient]} />
      <pointLight position={[0, 3.2, dollyZ]} intensity={LOOK.dolly} color="#ffe8c8" distance={0} decay={2} />
      {/* WORLD (rock + finished tunnel stay put while the machine advances) */}
      <Backdrop />
      <BoreWall />
      <WorldCaps />
      <Lining />
      <HeroRing />
      <BoreLamps />
      {/* MACHINE */}
      <group position={[0, 0, zm]}>
        <spotLight position={[6, 9, 15]} intensity={LOOK.key * intro} angle={0.62} penumbra={0.7} decay={2} color="#ffe6c4" castShadow shadow-mapSize={[1024, 1024]} shadow-bias={-0.0004} shadow-normalBias={0.05} shadow-camera-near={3} shadow-camera-far={70} />
        <pointLight position={[-6, 3, 6]} intensity={LOOK.fill} color="#8fb4ff" decay={2} />
        <pointLight position={[3, 2.2, -5.5]} intensity={LOOK.fill} color="#ffe2b8" decay={2} />
        <pointLight position={[0, 3.2, -10]} intensity={LOOK.fill * 0.9} color="#fff1d6" decay={2} />
        <pointLight position={[-3.5, 3, -17]} intensity={LOOK.fill * 0.8} color="#9bb8ff" decay={2} />
        <pointLight position={[0, 3.2, -24]} intensity={LOOK.fill * 0.7} color="#ffe2b8" decay={2} />
        <Cutterhead />
        <Shell />
        <Thrust />
        <Conveyor />
        <Gantry />
        <Erector />
        <Muck />
        <RockFace />
        <FaceDust />
      </group>
      <Dust />
    </>
  );
};

export const Scene3D: React.FC = () => (
  <ThreeCanvas
    width={FRAME_W}
    height={FRAME_H}
    shadows
    camera={{fov: 56, near: 0.3, far: 600, position: [0, 0, 30]}}
    gl={{antialias: true, powerPreference: 'high-performance'}}
    onCreated={({gl}) => {
      gl.toneMapping = THREE.ACESFilmicToneMapping; gl.toneMappingExposure = LOOK.exposure;
      gl.outputColorSpace = THREE.SRGBColorSpace; gl.localClippingEnabled = true;
      gl.shadowMap.type = THREE.PCFSoftShadowMap;
    }}
  >
    <Content />
  </ThreeCanvas>
);
