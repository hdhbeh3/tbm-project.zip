import React, {useLayoutEffect, useMemo, useRef} from 'react';
import * as THREE from 'three';
import {useCurrentFrame} from 'remotion';
import {FPS, cuttingAmt, faceOn, SCENES} from '../lib/motion';
import {cameraAt} from '../lib/camera';
import {hash01} from '../lib/rand';
import {mats} from '../lib/materials';
import {coneGradient} from '../lib/textures';

/** Volumetric-looking floating dust that stays around the camera target. */
export const Dust: React.FC = () => {
  const t = useCurrentFrame() / FPS, M = mats();
  const N = 700;
  const {geo, base, pos} = useMemo(() => {
    const base = new Float32Array(N * 3), pos = new Float32Array(N * 3);
    for (let i = 0; i < N * 3; i++) base[i] = hash01(i * 1.37 + 5);
    const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.BufferAttribute(pos, 3)); return {geo, base, pos};
  }, []);
  useLayoutEffect(() => {
    const tg = cameraAt(t).target, D = [34, 20, 46];
    for (let i = 0; i < N; i++) {
      const dr = [Math.sin(t * 0.3 + i) * 0.6 + t * 0.12, -t * 0.18, Math.cos(t * 0.25 + i * 0.7) * 0.6 - t * 0.35];
      for (let a = 0; a < 3; a++) { const v = base[i * 3 + a] * D[a] + dr[a]; pos[i * 3 + a] = (((v % D[a]) + D[a]) % D[a]) - D[a] / 2 + tg[a]; }
    }
    (geo.attributes.position as THREE.BufferAttribute).needsUpdate = true;
  });
  return <points geometry={geo} material={M.dust} frustumCulled={false} />;
};

/** Big soft rock-dust clouds thrown off the cutting face (machine frame). */
export const FaceDust: React.FC = () => {
  const t = useCurrentFrame() / FPS, M = mats();
  const N = 150;
  const {geo, pos} = useMemo(() => { const pos = new Float32Array(N * 3); const geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.BufferAttribute(pos, 3)); return {geo, pos}; }, []);
  const amt = faceOn(t) ? cuttingAmt(t) : 0.25;
  M.dustSoft.opacity = 0.05 + 0.1 * amt;
  useLayoutEffect(() => {
    for (let i = 0; i < N; i++) {
      const life = 2.6, a = (t + hash01(i * 3.3) * life) % life, s = (1 + 2 * hash01(i * 5.1)) * Math.PI / 2 + 0.2 * Math.sin(t + i), r = 1.2 + 4 * hash01(i * 7.9);
      pos[i * 3] = r * Math.cos(s) + Math.sin(t * 0.7 + i) * 0.4; pos[i * 3 + 1] = r * Math.sin(s) - 0.5 * a * a; pos[i * 3 + 2] = 0.5 + a * 1.6;
    }
    (geo.attributes.position as THREE.BufferAttribute).needsUpdate = true;
  });
  return <points geometry={geo} material={M.dustSoft} frustumCulled={false} />;
};

const Beam: React.FC<{from: [number, number, number]; to: [number, number, number]; radius: number; opacity?: number}> = ({from, to, radius, opacity = 0.05}) => {
  const {geo, q, mid, mat} = useMemo(() => {
    const a = new THREE.Vector3(...from), b = new THREE.Vector3(...to), dir = b.clone().sub(a), len = dir.length();
    const q = new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, -1, 0), dir.normalize());
    const mat = mats().beam.clone(); mat.opacity = opacity; mat.alphaMap = coneGradient();
    return {geo: new THREE.ConeGeometry(radius, len, 28, 1, true), q, mid: a.clone().add(b).multiplyScalar(0.5), mat};
  }, []);
  return <mesh geometry={geo} material={mat} position={mid} quaternion={q} />;
};

/** Work lights + light shafts in the bore ahead of the machine (scene 1 only: the machine is shown in its open launch bore). */
export const BoreLamps: React.FC = () => {
  const t = useCurrentFrame() / FPS, M = mats();
  if (t >= SCENES[1].start) return null;
  const zs = [10, 17, 24, 31, 38, 45, 52, 59];
  return (
    <group>
      {zs.map((z, i) => <mesh key={z} position={[i % 2 ? 3.1 : -3.1, 3.55, z]} rotation={[0, 0, i % 2 ? 0.8 : -0.8]} material={M.lamp}><boxGeometry args={[0.9, 0.18, 0.35]} /></mesh>)}
      <Beam from={[-3.1, 3.5, 10]} to={[-1.0, -0.6, 0.5]} radius={2.6} opacity={0.06} />
      <Beam from={[3.1, 3.5, 17]} to={[1.5, -1.0, 2.0]} radius={3.0} opacity={0.05} />
      <Beam from={[-3.1, 3.5, 24]} to={[-0.5, -1.5, 6]} radius={3.2} opacity={0.04} />
    </group>
  );
};
