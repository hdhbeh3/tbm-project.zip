import React, {useLayoutEffect, useMemo, useRef} from 'react';
import * as THREE from 'three';
import {useCurrentFrame} from 'remotion';
import {D2R, FPS, RAM_R, pressure, thrustExt} from '../lib/motion';
import {mats} from '../lib/materials';
import {box, cylZ, ringGeo} from './geo';

const N = 16;
const ang = (i: number) => (11.25 + 22.5 * i) * D2R;
const rot = (p: [number, number, number], a: number) => new THREE.Vector3(p[0] * Math.cos(a) - p[1] * Math.sin(a), p[0] * Math.sin(a) + p[1] * Math.cos(a), p[2]);

/** 16 thrust cylinders: barrels fixed to the thrust ring, piston rods extend rearward and push on the last lining ring. */
export const Thrust: React.FC = () => {
  const t = useCurrentFrame() / FPS, M = mats();
  const ext = thrustExt(t), p = pressure(t);
  M.barrel.emissiveIntensity = 0.55 * p; M.manifoldC.emissiveIntensity = 0.5 * p;
  const hoses = useMemo(() => {
    const out: {curve: THREE.CatmullRomCurve3; geo: THREE.TubeGeometry}[] = [];
    for (let i = 0; i < N; i++) {
      const a = ang(i);
      const A: [number, number, number][] = [[3.7, 0, -6.4], [4.0, 0.35, -6.5], [4.45, 0.4, -6.7], [RAM_R, 0.28, -6.85]];
      const B: [number, number, number][] = [[3.4, 0, -8.4], [3.8, -0.3, -8.9], [4.3, -0.4, -9.4], [RAM_R, -0.27, -9.7]];
      for (const pts of [A, B]) {
        const curve = new THREE.CatmullRomCurve3(pts.map(q => rot(q, a)));
        out.push({curve, geo: new THREE.TubeGeometry(curve, 24, 0.055, 6, false)});
      }
    }
    return out;
  }, []);
  const PUL = 4, pulses = useRef<THREE.InstancedMesh>(null!);
  const pulseGeo = useMemo(() => new THREE.SphereGeometry(0.1, 8, 6), []);
  const dummy = useMemo(() => new THREE.Object3D(), []);
  useLayoutEffect(() => {
    let k = 0;
    hoses.forEach((h, hi) => {
      for (let j = 0; j < PUL; j++) {
        const f = (j / PUL + t * 0.7 + hi * 0.13) % 1, pt = h.curve.getPointAt(f);
        dummy.position.copy(pt); const s = 0.9 * p * Math.sin(Math.PI * f) + 0.02; dummy.scale.setScalar(s); dummy.updateMatrix();
        pulses.current.setMatrixAt(k++, dummy.matrix);
      }
    });
    pulses.current.instanceMatrix.needsUpdate = true;
  });
  return (
    <group>
      {/* thrust ring that carries the barrels + two hydraulic manifold rings */}
      <mesh geometry={ringGeo(3.9, 4.95, 0.28, 72)} position={[0, 0, -6.55]} material={M.steelDarkC} />
      <mesh position={[0, 0, -6.4]} material={M.manifoldC}><torusGeometry args={[3.7, 0.11, 10, 72]} /></mesh>
      <mesh position={[0, 0, -8.4]} material={M.manifoldC}><torusGeometry args={[3.4, 0.11, 10, 72]} /></mesh>
      {Array.from({length: N}, (_, i) => (
        <group key={i} rotation={[0, 0, ang(i)]}>
          <mesh geometry={box(0.8, 0.55, 0.3)} position={[RAM_R - 0.1, 0, -6.72]} material={M.steelDark} />
          <mesh geometry={cylZ(0.24, 3.4, 24)} position={[RAM_R, 0, -8.3]} material={M.barrel} castShadow />
          <mesh geometry={cylZ(0.3, 0.26, 24)} position={[RAM_R, 0, -6.85]} material={M.steelDark} />
          <mesh geometry={cylZ(0.3, 0.26, 24)} position={[RAM_R, 0, -9.88]} material={M.steelDark} />
          <mesh geometry={cylZ(0.27, 0.12, 24)} position={[RAM_R, 0, -8.3]} material={M.yellow} />
          {/* piston rod: visible length = extension */}
          <mesh geometry={cylZ(0.13, 1, 18)} position={[RAM_R, 0, -10 - ext / 2]} scale={[1, 1, Math.max(ext, 0.01)]} material={M.steelCyl} castShadow />
          {/* pad shoe presses on the front face of the lining ring */}
          <group position={[RAM_R, 0, -10 - ext + 0.1]}>
            <mesh geometry={box(0.26, 0.64, 0.2)} material={M.steelDark} />
            <mesh geometry={box(0.28, 0.66, 0.04)} position={[0, 0, -0.1]} material={M.yellow} />
          </group>
        </group>
      ))}
      {hoses.map((h, i) => <mesh key={i} geometry={h.geo} material={M.hose} />)}
      {/* hydraulic-pressure flow (subtle blue) travelling manifold -> cylinder */}
      <instancedMesh ref={pulses} args={[pulseGeo, M.pulse, hoses.length * PUL]} frustumCulled={false} />
    </group>
  );
};
