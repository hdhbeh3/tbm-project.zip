import React from 'react';
import {FPS, R_SEG_IN, R_SEG_OUT, RING_LEN, ZM_INSTALL, Z_RING_N, erectorState, zmAt} from '../lib/motion';
import {mats} from '../lib/materials';
import {box, cylZ, ringGeo, segmentGeo} from './geo';
import {useCurrentFrame} from 'remotion';
import {SEGS} from '../lib/motion';

/** Segment erector: slide beams, rotating ring bearing, telescoping hydraulic boom and vacuum gripper pad. (machine frame) */
export const Erector: React.FC = () => {
  const t = useCurrentFrame() / FPS, M = mats(), es = erectorState(t);
  M.erectorYellow.emissiveIntensity = es.gripping ? 0.55 : 0;
  const rodLen = Math.max(0.08, es.rg - 0.2 - 3.0);
  return (
    <group>
      {/* axial slide beams (fixed to the shield) + feeder trolley rails with the staging cradle */}
      {[-1.6, 1.6].map(x => <mesh key={x} geometry={box(0.28, 0.28, 4.6)} position={[x, 0.9, -10.6]} material={M.machine} />)}
      {[-0.9, 0.9].map(x => <mesh key={'r' + x} geometry={box(0.1, 0.14, 6.5)} position={[x, -3.95, -11.2]} material={M.steelDark} />)}
      <mesh geometry={box(2.3, 0.12, 1.7)} position={[0, -3.98, -9.4]} material={M.yellow} />
      {/* carriage: slides along z with the segment */}
      <group position={[0, 0, es.s]}>
        <mesh geometry={ringGeo(2.0, 2.6, 0.55, 64)} material={M.steelDark} castShadow />
        <mesh geometry={ringGeo(2.0, 2.62, 0.08, 64)} position={[0, 0, 0.3]} material={M.yellow} />
        <group rotation={[0, 0, es.alpha]}>
          {/* telescoping boom: barrel + rod + swivel + vacuum pad */}
          <mesh geometry={box(0.9, 0.36, 0.36)} position={[2.75, 0, 0]} material={M.machine} castShadow />
          <mesh position={[3.0 + rodLen / 2, 0, 0]} rotation={[0, 0, Math.PI / 2]} scale={[1, rodLen, 1]} material={M.steelCyl}><cylinderGeometry args={[0.13, 0.13, 1, 16]} /></mesh>
          <mesh position={[es.rg - 0.2, 0, 0]} material={M.steelDark}><sphereGeometry args={[0.17, 14, 10]} /></mesh>
          <mesh geometry={box(0.14, 1.5, 1.0)} position={[es.rg - 0.07, 0, 0]} material={M.erectorYellow} castShadow />
          <mesh geometry={box(0.1, 0.5, 0.5)} position={[es.rg - 0.2, 0, 0]} material={M.steelDark} />
          {/* counterweight + hydraulic hose bundle */}
          <mesh geometry={box(0.7, 0.55, 0.5)} position={[-2.35, 0, 0]} material={M.steelDark} />
          <mesh position={[2.3, 0.28, 0]} rotation={[0, 0, Math.PI / 2]} material={M.hose}><cylinderGeometry args={[0.05, 0.05, 1.6, 8]} /></mesh>
        </group>
      </group>
    </group>
  );
};

/** The six precast concrete segments of ring N. WORLD frame: once placed they stay put while the machine advances. */
export const HeroRing: React.FC = () => {
  const t = useCurrentFrame() / FPS, M = mats(), es = erectorState(t), zm = zmAt(t);
  return (
    <group>
      {SEGS.map((s, i) => {
        const p = es.segs[i];
        if (!p.visible) return null;
        const zWorld = p.state === 'placed' ? ZM_INSTALL + Z_RING_N : zm + p.z;
        return (
          <group key={i} position={[0, 0, zWorld]} rotation={[0, 0, p.angle]}>
            <mesh geometry={segmentGeo(R_SEG_IN, R_SEG_OUT, s.w - 0.5, RING_LEN - 0.06)} position={[p.rOff, 0, 0]} material={M.concreteHero} castShadow receiveShadow />
          </group>
        );
      })}
    </group>
  );
};
