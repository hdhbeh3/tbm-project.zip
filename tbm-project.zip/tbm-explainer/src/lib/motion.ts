import tl from '../data/timeline.json';

export const FPS = 30;
export const TOTAL_FRAMES = 1260; // = 41.999 s voiceover
export const SCENES = tl.scenes;
export const sceneAt = (t: number) => { let i = 0; for (let k = 0; k < SCENES.length; k++) if (t >= SCENES[k].start) i = k; return i; };

export const clamp = (x: number, a = 0, b = 1) => Math.min(b, Math.max(a, x));
export const smooth = (x: number) => { x = clamp(x); return x * x * (3 - 2 * x); };
export const ramp = (t: number, a: number, b: number) => clamp((t - a) / (b - a));
export const sstep = (t: number, a: number, b: number) => smooth(ramp(t, a, b));
export const lerp = (a: number, b: number, x: number) => a + (b - a) * x;
export const win = (t: number, a: number, b: number, fi = 0.3, fo = 0.3) => sstep(t, a, a + fi) * (1 - sstep(t, b - fo, b));
export const D2R = Math.PI / 180;

// ---------------- machine dimensions (metres) ----------------
export const R_HEAD = 5.25, R_BORE = 5.22, R_SHIELD = 5.1, R_SHIELD_IN = 4.95;
export const R_SEG_IN = 4.35, R_SEG_OUT = 4.85, RING_LEN = 1.6;
export const RAM_R = 4.6;              // radius of the thrust-cylinder circle
export const BELT_V = 3.0;             // belt speed m/s
export const BELT_Y = -0.55;
export const Z_RING_N = -11.2;         // local z centre of the ring being built (at zm = 1.6)
export const ZM_INSTALL = 1.6;

// ---------------- cutterhead angle (integrated, slows while the ring is built) ----------------
const OMEGA = 0.55;
function headSpeed(t: number) {
  const down = sstep(t, 25.2, 26.2), up = sstep(t, 33.8, 35.0);
  return 1 - 0.9 * down * (1 - up);
}
const STEP = 1 / 240, NT = Math.ceil(44 / STEP) + 2;
const thRaw = new Float64Array(NT), zmRaw = new Float64Array(NT);
const VK: [number, number][] = [[0, 0.05], [12.2, 0.05], [13.6, 0.19], [19.8, 0.19], [21.5, 0.05], [24.2, 0.05], [25.0, 0], [34.4, 0], [35.3, 0.2], [42.1, 0.2]];
function vAt(t: number) {
  for (let i = 1; i < VK.length; i++) if (t <= VK[i][0]) return lerp(VK[i - 1][1], VK[i][1], (t - VK[i - 1][0]) / (VK[i][0] - VK[i - 1][0]));
  return VK[VK.length - 1][1];
}
for (let i = 1; i < NT; i++) {
  const t = i * STEP;
  thRaw[i] = thRaw[i - 1] + OMEGA * headSpeed(t - STEP / 2) * STEP;
  zmRaw[i] = zmRaw[i - 1] + vAt(t - STEP / 2) * STEP;
}
const tab = (a: Float64Array, t: number) => {
  const f = clamp(t / STEP, 0, NT - 1.001), i = Math.floor(f);
  return a[i] + (a[i + 1] - a[i]) * (f - i);
};
const BUCKET0 = 30 * D2R;
// phase chosen so bucket 0 discharges at the top at t = 19.0 s (rocks reach the belt as the conveyor scene starts)
const PHASE = (((Math.PI / 2 - BUCKET0 - tab(thRaw, 19.0)) % (2 * Math.PI)) + 2 * Math.PI) % (2 * Math.PI);
export const headAngle = (t: number) => tab(thRaw, t) + PHASE;
export function thetaInv(theta: number) { // inverse of headAngle (monotonic)
  const target = theta - PHASE; if (target <= 0) return target / OMEGA; // before t=0: constant start speed
  let lo = 0, hi = NT - 1;
  while (hi - lo > 1) { const m = (lo + hi) >> 1; if (thRaw[m] < target) lo = m; else hi = m; }
  return (lo + (target - thRaw[lo]) / (thRaw[hi] - thRaw[lo] || 1)) * STEP;
}
export const headRate = (t: number) => OMEGA * headSpeed(t);

// ---------------- machine advance along the tunnel axis (+z = forward) ----------------
const s1 = 1.6 / tab(zmRaw, 25.0), s2 = 1.6 / (tab(zmRaw, 42.0) - tab(zmRaw, 34.4));
export function zmAt(t: number) {
  if (t <= 25.0) return tab(zmRaw, t) * s1;
  if (t <= 34.4) return 1.6;
  return 1.6 + (tab(zmRaw, t) - tab(zmRaw, 34.4)) * s2;
}
/** thrust-cylinder rod extension (m). Shove 1: 0.4 -> 2.0, retract to make room for ring N, shove 2 again from 0.4 */
export function thrustExt(t: number) {
  const z = zmAt(t);
  if (t < 25.0) return 0.4 + z;
  if (t < 34.4) return lerp(2.0, 0.4, sstep(t, 25.3, 26.3));
  return 0.4 + (z - 1.6);
}
/** hydraulic pressure 0..1 (drives the blue flow highlight) */
export const pressure = (t: number) => clamp(0.22 + 0.78 * win(t, 13.4, 19.9, 0.5, 0.6) + 0.78 * win(t, 34.8, 42.5, 0.6, 0.4) + 0.4 * win(t, 25.3, 26.3, 0.2, 0.3));
/** machine-local z at which the bore face (rock) sits */
export const FACE_Z = 0.2;

// ---------------- segment erector ----------------
export const ERECT_START = tl.erector.start, ERECT_CYCLE = tl.erector.cycle;
export const SEGS = [
  { name: 'A3', angle: 270, w: 64 }, { name: 'A2', angle: 206, w: 64 }, { name: 'A4', angle: 334, w: 64 },
  { name: 'A1', angle: 142, w: 64 }, { name: 'A5', angle: 38, w: 64 }, { name: 'K', angle: 90, w: 40 },
];
const PICK_ANGLE = 270, PICK_Z = -9.4, PLACE_Z = Z_RING_N, RG_CARRY = 3.8, RG_SEAT = R_SEG_IN, RG_PICK = 3.3; // segments are staged INSIDE the lining radius (feeder trolley)
export const STAGED_ROFF = RG_PICK - R_SEG_IN;
const ALPHA0 = 250; // erector parked just beside the feeder tray
const shortest = (from: number, to: number) => { let d = (((to - from) % 360) + 540) % 360 - 180; return from + d; };

export interface SegPose { visible: boolean; state: 'staged' | 'carried' | 'placed'; angle: number; rOff: number; z: number }
export interface ErectorState { alpha: number; rg: number; s: number; gripping: boolean; segs: SegPose[] }

export function erectorState(t: number): ErectorState {
  let alpha = ALPHA0, rg = RG_CARRY, s = PICK_Z, gripping = false;
  const segs: SegPose[] = SEGS.map(() => ({ visible: false, state: 'staged', angle: PICK_ANGLE * D2R, rOff: RG_PICK - R_SEG_IN, z: PICK_Z }));
  let prevAngle = ALPHA0, prevS = PICK_Z;
  for (let i = 0; i < SEGS.length; i++) {
    const t0 = ERECT_START + i * ERECT_CYCLE, u = (t - t0) / ERECT_CYCLE, seg = SEGS[i];
    const target = shortest(PICK_ANGLE, seg.angle);                    // path from tray to slot (shortest way round)
    const slide = (e: number) => lerp(PICK_Z, PLACE_Z, e);
    // pose of the segment itself
    const p = segs[i];
    if (i === 0 ? t >= 25.4 : u >= -0.25) p.visible = true;
    if (u < 0) { // delivered along the feeder toward the tray
      p.z = i === 0 ? PICK_Z : lerp(PICK_Z - 4.5, PICK_Z, smooth((u + 0.25) / 0.25));
    }
    if (u >= 0.30 && u < 0.90) p.state = 'carried';
    if (u >= 0.90) p.state = 'placed';
    if (u >= 0 && u < 1.0) {
      // erector motion during this cycle: return -> descend onto tray -> grip & lift -> rotate+slide -> seat -> release/retract
      if (u < 0.30) {
        const e = smooth(u / 0.24);
        alpha = lerp(prevAngle, shortest(prevAngle, PICK_ANGLE), e); s = lerp(prevS, PICK_Z, e);
        rg = lerp(RG_CARRY, RG_PICK, smooth((u - 0.20) / 0.10));
      }
      else if (u < 0.38) { alpha = PICK_ANGLE; s = PICK_Z; rg = lerp(RG_PICK, RG_CARRY, smooth((u - 0.30) / 0.08)); gripping = true; }
      else if (u < 0.80) { const e = smooth((u - 0.38) / 0.42); alpha = lerp(PICK_ANGLE, target, e); s = slide(e); rg = RG_CARRY; gripping = true; }
      else if (u < 0.90) { alpha = target; s = PLACE_Z; rg = lerp(RG_CARRY, RG_SEAT, smooth((u - 0.80) / 0.10)); gripping = true; }
      else { alpha = target; s = PLACE_Z; rg = lerp(RG_SEAT, RG_CARRY, smooth((u - 0.90) / 0.10)); }
    }
    if (u >= 1.0) { prevAngle = ((target % 360) + 360) % 360; prevS = PLACE_Z; alpha = prevAngle; s = PLACE_Z; rg = RG_CARRY; }
    if (p.state === 'carried') { p.angle = alpha * D2R; p.rOff = rg - RG_SEAT; p.z = s; }
    else if (p.state === 'placed') { p.angle = seg.angle * D2R; p.rOff = 0; p.z = PLACE_Z; }
    else p.angle = PICK_ANGLE * D2R;
  }
  return { alpha: alpha * D2R, rg, s, gripping, segs };
}
export const RING_DONE_T = ERECT_START + 5 * ERECT_CYCLE + 0.90 * ERECT_CYCLE;

// ---------------- global scene state ----------------
export const faceOn = (t: number) => t >= SCENES[1].start;       // rock face + cutaway exist from scene 2 on
export const cutC = (t: number) => (t >= SCENES[1].start ? 0 : 99);  // cut plane x <= c
export const heroCutC = (t: number) => (t >= SCENES[5].start ? 0 : 99);
export const cuttingAmt = (t: number) => (faceOn(t) ? 1 - sstep(t, 25.2, 26.2) * (1 - sstep(t, 33.8, 35.0)) * 0.95 : 0);
