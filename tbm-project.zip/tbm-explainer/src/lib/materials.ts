import * as THREE from 'three';
import {LOOK} from '../config';
import {concreteBump, concreteColor, radialSprite, repeated, rockColor, rockHeight, rockSection} from './textures';

// Shared cutaway planes: everything "kept" has x <= constant. (99 = nothing cut)
export const cutPlane = new THREE.Plane(new THREE.Vector3(-1, 0, 0), 99);
export const heroPlane = new THREE.Plane(new THREE.Vector3(-1, 0, 0), 99);   // ring N has its own plane
export const facePlane = new THREE.Plane(new THREE.Vector3(0, 0, -1), 99);   // hides bore wall in front of the rock face
const CUT = [cutPlane, facePlane];

let M: ReturnType<typeof build> | null = null;
export const mats = () => M || (M = build());

function build() {
  const std = (p: THREE.MeshStandardMaterialParameters) => new THREE.MeshStandardMaterial({...p, envMapIntensity: (p.envMapIntensity ?? 1) * LOOK.envIntensity});
  const clip = (m: THREE.MeshStandardMaterial, planes: THREE.Plane[]) => { m.clippingPlanes = planes; m.clipShadows = true; m.side = THREE.DoubleSide; return m; };
  return {
    steelDark: std({color: '#2b2e33', metalness: 0.85, roughness: 0.42, envMapIntensity: 0.9}),
    steelPolish: std({color: '#cfd4da', metalness: 1, roughness: 0.17, envMapIntensity: 1.1}),
    discEdge: std({color: '#d7dbe0', metalness: 1, roughness: 0.14, emissive: new THREE.Color('#ffb21f'), emissiveIntensity: 0, envMapIntensity: 1.1}),
    steelCyl: std({color: '#aab1b8', metalness: 0.95, roughness: 0.22, envMapIntensity: 1.0}),
    barrel: std({color: '#4f5560', metalness: 0.7, roughness: 0.38, emissive: new THREE.Color('#2f7dff'), emissiveIntensity: 0, envMapIntensity: 0.9}),
    machine: std({color: '#6e737a', metalness: 0.55, roughness: 0.55, envMapIntensity: 0.8}),
    shell: clip(std({color: '#686d73', metalness: 0.55, roughness: 0.6, envMapIntensity: 0.7}), CUT),
    machineC: clip(std({color: '#6e737a', metalness: 0.55, roughness: 0.55, envMapIntensity: 0.8}), CUT),
    steelDarkC: clip(std({color: '#2b2e33', metalness: 0.85, roughness: 0.42, envMapIntensity: 0.9}), CUT),
    rubberC: clip(std({color: '#0d0d0f', metalness: 0, roughness: 0.88}), CUT),
    manifoldC: clip(std({color: '#4f5560', metalness: 0.7, roughness: 0.38, emissive: new THREE.Color('#2f7dff'), emissiveIntensity: 0}), CUT),
    yellow: std({color: '#d99a00', metalness: 0.3, roughness: 0.5}),
    yellowShell: clip(std({color: '#d99a00', metalness: 0.3, roughness: 0.5}), CUT),
    rubber: std({color: '#0d0d0f', metalness: 0, roughness: 0.88}),
    hose: std({color: '#15171a', metalness: 0.1, roughness: 0.55}),
    erectorYellow: std({color: '#d4960a', metalness: 0.3, roughness: 0.5, emissive: new THREE.Color('#ffc233'), emissiveIntensity: 0}),
    concrete: clip(std({color: '#a3a39e', map: concreteColor(), bumpMap: concreteBump(), bumpScale: 1.2, roughness: 0.93}), CUT),
    concreteHero: (() => { const m = std({color: '#a3a39e', map: concreteColor(), bumpMap: concreteBump(), bumpScale: 1.2, roughness: 0.93}); m.clippingPlanes = [heroPlane]; m.clipShadows = true; m.side = THREE.DoubleSide; return m; })(),
    bore: (() => { const m = std({color: '#ffffff', map: repeated(rockColor(), 10, 40), bumpMap: repeated(rockHeight(), 10, 40, false), bumpScale: 4, roughness: 1, side: THREE.BackSide}); m.clippingPlanes = CUT; m.clipShadows = true; return m; })(),
    face: std({color: '#ffffff', roughness: 1, metalness: 0}), // map assigned by the component
    section: std({color: '#ffffff', map: repeated(rockSection(), 6, 3), bumpMap: repeated(rockHeight(), 6, 3, false), bumpScale: 3, roughness: 1}),
    chip: std({color: '#756e64', roughness: 1, flatShading: true}),
    rock: std({color: '#6b645a', roughness: 1, flatShading: true}),
    pulse: new THREE.MeshBasicMaterial({color: '#4aa3ff', transparent: true, opacity: 0.95, toneMapped: false}),
    lamp: new THREE.MeshBasicMaterial({color: '#fff0d2', toneMapped: false}),
    backdrop: new THREE.MeshBasicMaterial({color: '#4a3f33', map: repeated(rockColor(), 14, 7), side: THREE.BackSide, fog: false}),
    beam: new THREE.MeshBasicMaterial({color: '#ffe6bd', transparent: true, opacity: 0.05, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false}),
    dust: new THREE.PointsMaterial({color: '#ffe2b8', size: 0.14, map: radialSprite(), transparent: true, opacity: 0.55, depthWrite: false, blending: THREE.AdditiveBlending, sizeAttenuation: true}),
    dustSoft: new THREE.PointsMaterial({color: '#bfae95', size: 0.9, map: radialSprite(), transparent: true, opacity: 0.12, depthWrite: false, blending: THREE.AdditiveBlending, sizeAttenuation: true}),
  };
}
