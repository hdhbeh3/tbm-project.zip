export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
/** deterministic 0..1 hash of a number */
export function hash01(n: number) {
  const x = Math.sin(n * 127.1 + 311.7) * 43758.5453;
  return x - Math.floor(x);
}
function h3(ix: number, iy: number, iz: number, s: number) {
  let n = Math.imul(ix, 374761393) ^ Math.imul(iy, 668265263) ^ Math.imul(iz, 1274126177) ^ Math.imul(s, 2147483647);
  n = Math.imul(n ^ (n >>> 13), 1274126177);
  n = n ^ (n >>> 16);
  return (n >>> 0) / 4294967296;
}
const fade = (t: number) => t * t * (3 - 2 * t);
/** value noise in 3D; period>0 makes it tile with that lattice period on every axis */
export function vnoise3(x: number, y: number, z: number, seed = 0, period = 0) {
  const x0 = Math.floor(x), y0 = Math.floor(y), z0 = Math.floor(z);
  const fx = fade(x - x0), fy = fade(y - y0), fz = fade(z - z0);
  const w = (v: number) => (period > 0 ? ((v % period) + period) % period : v);
  let r = 0;
  for (let dz = 0; dz < 2; dz++)
    for (let dy = 0; dy < 2; dy++)
      for (let dx = 0; dx < 2; dx++) {
        const wt = (dx ? fx : 1 - fx) * (dy ? fy : 1 - fy) * (dz ? fz : 1 - fz);
        r += wt * h3(w(x0 + dx), w(y0 + dy), w(z0 + dz), seed);
      }
  return r;
}
export function fbm3(x: number, y: number, z: number, oct = 4, seed = 0, period = 0) {
  let a = 0.5, f = 1, s = 0, n = 0;
  for (let o = 0; o < oct; o++) {
    s += a * vnoise3(x * f, y * f, z * f, seed + o * 17, period ? period * f : 0);
    n += a; a *= 0.5; f *= 2;
  }
  return s / n;
}
