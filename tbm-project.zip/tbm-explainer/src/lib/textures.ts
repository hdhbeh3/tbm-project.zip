import * as THREE from 'three';
import {fbm3, hash01, mulberry32} from './rand';

// All surface textures are generated procedurally at load (seeded -> identical every render). No image files.
type RGB = [number, number, number];
function make(size: number, srgb: boolean, px: (u: number, v: number) => RGB): THREE.CanvasTexture {
  const c = document.createElement('canvas'); c.width = c.height = size;
  const ctx = c.getContext('2d')!; const img = ctx.createImageData(size, size);
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    const [r, g, b] = px(x / size, y / size), i = (y * size + x) * 4;
    img.data[i] = Math.max(0, Math.min(255, r * 255)); img.data[i + 1] = Math.max(0, Math.min(255, g * 255)); img.data[i + 2] = Math.max(0, Math.min(255, b * 255)); img.data[i + 3] = 255;
  }
  ctx.putImageData(img, 0, 0);
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping; t.anisotropy = 4;
  if (srgb) t.colorSpace = THREE.SRGBColorSpace;
  return t;
}
const hfun = (u: number, v: number, f: number, oct: number, seed: number) => fbm3(u * f, v * f, 7.3, oct, seed, f); // tileable (period = f)

let cache: Record<string, THREE.CanvasTexture> = {};
const once = (k: string, fn: () => THREE.CanvasTexture) => cache[k] || (cache[k] = fn());

export function rockHeight() { return once('rockH', () => make(256, false, (u, v) => { const h = hfun(u, v, 6, 5, 3) * 0.8 + hfun(u, v, 24, 2, 9) * 0.2; return [h, h, h]; })); }
export function rockColor() {
  return once('rockC', () => make(512, true, (u, v) => {
    const h = hfun(u, v, 6, 5, 3), s = hfun(u, v, 40, 2, 5), band = 0.5 + 0.5 * Math.sin((v * 9 + h * 3) * 6.2832);
    const k = 0.13 + 0.17 * h + 0.05 * band + 0.05 * s;
    return [k * 1.05, k * 0.93, k * 0.8];
  }));
}
export function rockSection() {
  return once('rockS', () => make(512, true, (u, v) => {
    const h = hfun(u, v, 5, 4, 21), band = 0.5 + 0.5 * Math.sin((v * 14 + h * 4) * 6.2832);
    const k = 0.2 + 0.16 * h + 0.07 * band;
    return [k * 1.0, k * 0.92, k * 0.82];
  }));
}
export function concreteColor() {
  return once('conC', () => make(512, true, (u, v) => {
    const n = hfun(u, v, 10, 4, 31), f = hfun(u, v, 64, 2, 8), pore = hash01(Math.floor(u * 256) * 131 + Math.floor(v * 256) * 7) > 0.985 ? 0.55 : 1;
    const form = (Math.abs(((v * 6) % 1) - 0.5) < 0.012) ? 0.88 : 1;
    const k = (0.5 + 0.12 * n + 0.04 * f) * pore * form;
    return [k, k * 0.995, k * 0.97];
  }));
}
export function concreteBump() { return once('conB', () => make(256, false, (u, v) => { const n = hfun(u, v, 32, 3, 12); return [n, n, n]; })); }
/** rock-face texture: kerf rings at the disc-cutter radii + radial fractures (square canvas mapped across the disc) */
export function faceTexture(radii: number[], R: number) {
  return once('face', () => {
    const size = 1024;
    const t = make(size, true, (u, v) => {
      const x = (u - 0.5) * 2 * R, y = (v - 0.5) * 2 * R, h = fbm3(x * 0.9, y * 0.9, 3, 5, 14);
      const r = Math.hypot(x, y); let kerf = 0;
      for (const rr of radii) kerf = Math.max(kerf, Math.exp(-Math.pow((r - rr) / 0.07, 2)));
      const k = (0.2 + 0.2 * h) * (1 - 0.6 * kerf);
      return [k * 1.05, k * 0.95, k * 0.82];
    });
    const ctx = (t.image as HTMLCanvasElement).getContext('2d')!; const rnd = mulberry32(77);
    ctx.lineCap = 'round';
    for (let i = 0; i < 260; i++) {
      const rr = radii[Math.floor(rnd() * radii.length)], a = rnd() * 6.2832;
      let x = size / 2 + (Math.cos(a) * rr * size) / (2 * R), y = size / 2 + (Math.sin(a) * rr * size) / (2 * R);
      let ang = a + (rnd() - 0.5) * 1.6; ctx.strokeStyle = `rgba(8,6,5,${0.45 + rnd() * 0.4})`; ctx.lineWidth = 0.8 + rnd() * 1.8; ctx.beginPath(); ctx.moveTo(x, y);
      const n = 4 + Math.floor(rnd() * 6);
      for (let k = 0; k < n; k++) { ang += (rnd() - 0.5) * 0.9; x += Math.cos(ang) * (6 + rnd() * 16); y += Math.sin(ang) * (6 + rnd() * 16); ctx.lineTo(x, y); }
      ctx.stroke();
    }
    t.wrapS = t.wrapT = THREE.ClampToEdgeWrapping; t.needsUpdate = true;
    return t;
  });
}
export function radialSprite() {
  return once('sprite', () => {
    const c = document.createElement('canvas'); c.width = c.height = 64; const g = c.getContext('2d')!;
    const gr = g.createRadialGradient(32, 32, 0, 32, 32, 32); gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.4, 'rgba(255,255,255,0.35)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = gr; g.fillRect(0, 0, 64, 64); return new THREE.CanvasTexture(c);
  });
}
export function coneGradient() {
  return once('cone', () => {
    const c = document.createElement('canvas'); c.width = 8; c.height = 128; const g = c.getContext('2d')!;
    const gr = g.createLinearGradient(0, 0, 0, 128); gr.addColorStop(0, 'rgba(255,255,255,0.0)'); gr.addColorStop(1, 'rgba(255,255,255,1)');
    g.fillStyle = gr; g.fillRect(0, 0, 8, 128); return new THREE.CanvasTexture(c);
  });
}
export function repeated(tex: THREE.Texture, rx: number, ry: number, srgb = true) {
  const t = tex.clone(); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(rx, ry); t.needsUpdate = true; if (srgb) t.colorSpace = THREE.SRGBColorSpace; return t;
}
