// Tiny vector + camera-projection math (no three.js import) so the SAME camera code
// drives the 3D camera, the label overlay and the offline safe-zone check.
export type V3 = [number, number, number];
export const add = (a: V3, b: V3): V3 => [a[0] + b[0], a[1] + b[1], a[2] + b[2]];
export const sub = (a: V3, b: V3): V3 => [a[0] - b[0], a[1] - b[1], a[2] - b[2]];
export const mul = (a: V3, s: number): V3 => [a[0] * s, a[1] * s, a[2] * s];
export const dot = (a: V3, b: V3) => a[0] * b[0] + a[1] * b[1] + a[2] * b[2];
export const cross = (a: V3, b: V3): V3 => [a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]];
export const len = (a: V3) => Math.hypot(a[0], a[1], a[2]);
export const norm = (a: V3): V3 => { const l = len(a) || 1; return [a[0] / l, a[1] / l, a[2] / l]; };
export const lerp3 = (a: V3, b: V3, t: number): V3 => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t, a[2] + (b[2] - a[2]) * t];

export const FRAME_W = 1080;
export const FRAME_H = 1920;
/** YouTube Shorts conservative safe zone: top 12%, right 18%, bottom 22% reserved. */
export const SAFE = { left: 0, right: FRAME_W * 0.82, top: FRAME_H * 0.12, bottom: FRAME_H * 0.78 };
/** The principal point is shifted so the camera target lands in the middle of the safe zone. */
export const SHIFT = { x: FRAME_W / 2 - (SAFE.left + SAFE.right) / 2, y: FRAME_H / 2 - (SAFE.top + SAFE.bottom) / 2 };

export interface CamState { pos: V3; target: V3; fov: number; roll: number }

export function rotateAbout(v: V3, axis: V3, ang: number): V3 {
  const c = Math.cos(ang), s = Math.sin(ang), k = cross(axis, v), d = dot(axis, v) * (1 - c);
  return [v[0] * c + k[0] * s + axis[0] * d, v[1] * c + k[1] * s + axis[1] * d, v[2] * c + k[2] * s + axis[2] * d];
}
export function camUp(cam: CamState): V3 {
  const f = norm(sub(cam.target, cam.pos));
  return cam.roll ? rotateAbout([0, 1, 0], f, cam.roll) : [0, 1, 0];
}
/** world point -> pixel in the 1080x1920 frame (matches three's setViewOffset shift) */
export function project(cam: CamState, p: V3) {
  const f = norm(sub(cam.target, cam.pos));
  const up = camUp(cam);
  const r = norm(cross(f, up));
  const u = cross(r, f);
  const rel = sub(p, cam.pos);
  const xc = dot(rel, r), yc = dot(rel, u), zc = dot(rel, f);
  const th = Math.tan((cam.fov * Math.PI) / 360);
  const ndcX = xc / (zc * th * (FRAME_W / FRAME_H));
  const ndcY = yc / (zc * th);
  return { x: FRAME_W / 2 + (ndcX * FRAME_W) / 2 - SHIFT.x, y: FRAME_H / 2 - (ndcY * FRAME_H) / 2 - SHIFT.y, depth: zc };
}
export const inSafe = (x: number, y: number, pad = 0) =>
  x >= SAFE.left + pad && x <= SAFE.right - pad && y >= SAFE.top + pad && y <= SAFE.bottom - pad;
