import {CamState, V3, add, lerp3} from './math3d';
import {D2R, FPS, SCENES, zmAt, smooth, clamp, BELT_V} from './motion';

type Orbit = { tgt: V3; r: number; az: number; el: number };
interface Key { t: number; fov: number; roll?: number; pos?: V3; tgt?: V3; orb?: Orbit; e?: 'out' | 'inout' | 'lin' }
const O = (tgt: V3, r: number, az: number, el: number): Orbit => ({ tgt, r, az, el });
// Machine-local coordinates (+z = forward/cutterhead). az: 0 = +X side, +az swings toward the front, -az toward the rear.
const orbPos = (o: Orbit): V3 => [o.tgt[0] + o.r * Math.cos(o.el * D2R) * Math.cos(o.az * D2R), o.tgt[1] + o.r * Math.sin(o.el * D2R), o.tgt[2] + o.r * Math.cos(o.el * D2R) * Math.sin(o.az * D2R)];

const [c0, c1, c2, c3, c4, c5, c6] = [0, ...SCENES.map(s => s.end)];
const beltZ = (t: number) => -2.2 - BELT_V * Math.max(0, t - 20.55);

const KEYS: Key[][] = [
  // 1 — giant machine: fast push toward the cutterhead, then slow settle
  [
    { t: c0, fov: 58, pos: [3.6, 2.4, 36], tgt: [0, 0.2, 0], e: 'out' },
    { t: 1.2, fov: 58, pos: [2.0, 1.6, 26.5], tgt: [0, 0.2, -0.3], e: 'inout' },
    { t: c1, fov: 56, roll: -1.5 * D2R, pos: [-2.4, 1.2, 25.0], tgt: [0, 0.2, -0.5] },
  ],
  // 2 — cutterhead: oblique section view, then close-up on the disc cutters
  [
    { t: c1, fov: 46, orb: O([0, 0.3, -0.2], 25, 38, 10), e: 'inout' },
    { t: 8.9, fov: 46, orb: O([0, 0.8, 0], 23, 24, 8), e: 'inout' },
    { t: 10.2, fov: 40, orb: O([0, 3.2, 0.15], 9.8, 36, 6), e: 'inout' },
    { t: c2, fov: 40, orb: O([0, 3.2, 0.15], 9.0, 16, 5) },
  ],
  // 3 — hydraulics: head spinning -> thrust cylinders -> buckets
  [
    { t: c2, fov: 48, orb: O([0, 1.0, -0.8], 20, 28, 10), e: 'inout' },
    { t: 13.9, fov: 48, orb: O([0, 0.8, -4], 19, 14, 10), e: 'inout' },
    { t: 14.9, fov: 48, orb: O([0, 0.5, -8.6], 18.5, -6, 12), e: 'inout' },
    { t: 16.5, fov: 48, orb: O([0, 0.5, -9.4], 18.5, -26, 12), e: 'inout' },
    { t: 17.5, fov: 46, orb: O([0, -2.4, -0.4], 13, 34, 8), e: 'inout' },
    { t: c3, fov: 46, orb: O([0, -1.8, -0.5], 12.5, 22, 10) },
  ],
  // 4 — conveyor: camera tracks the rocks down the belt
  [
    { t: c3, fov: 50, orb: O([0, 0.8, -2.0], 11, 52, 22), e: 'inout' },
    { t: 21.0, fov: 50, orb: O([0, -0.2, beltZ(21.0)], 11, 12, 14), e: 'inout' },
    { t: c4, fov: 50, orb: O([0, -0.2, beltZ(c4)], 11.5, 4, 14), e: 'lin' },
  ],
  // 5 — segment erector: controlled orbit around the installation, ends on the rear view of the finished ring
  [
    { t: c4, fov: 50, orb: O([0, 0, -10.8], 21, 10, 10), e: 'inout' },
    { t: 28.8, fov: 50, orb: O([0, 0, -10.8], 20.5, -22, 12), e: 'inout' },
    { t: 32.3, fov: 52, orb: O([0, 0, -10.8], 23.5, -52, 9), e: 'inout' },
    { t: c5, fov: 52, orb: O([0, 0, -10.8], 25, -66, 7) },
  ],
  // 6 — full reveal: side cutaway, roll to a vertical composition, pull back
  [
    { t: c5, fov: 50, roll: -22 * D2R, orb: O([0, 0.3, -8.5], 22, 4, 6), e: 'inout' },
    { t: 37.4, fov: 50, roll: -52 * D2R, orb: O([0, 0, -9.5], 30, 6, 5), e: 'inout' },
    { t: c6, fov: 50, roll: -80 * D2R, orb: O([0, 0, -13], 48, 8, 4) },
  ],
];
const ease = (e: Key['e'], x: number) => (e === 'out' ? 1 - Math.pow(1 - x, 3) : e === 'lin' ? x : smooth(x));
const resolve = (k: Key) => ({ pos: k.pos ?? orbPos(k.orb!), tgt: k.tgt ?? k.orb!.tgt });

/** camera in WORLD coordinates (follows the machine so the mechanism stays framed) */
export function cameraAt(t: number): CamState {
  const si = SCENES.findIndex((s, i) => t >= s.start && (i === SCENES.length - 1 || t < SCENES[i + 1].start));
  const ks = KEYS[Math.max(0, si)];
  let a = ks[0], b = ks[ks.length - 1];
  for (let i = 0; i < ks.length - 1; i++) if (t >= ks[i].t && t <= ks[i + 1].t) { a = ks[i]; b = ks[i + 1]; break; }
  if (t >= ks[ks.length - 1].t) a = b = ks[ks.length - 1];
  const x = b.t === a.t ? 1 : ease(a.e, clamp((t - a.t) / (b.t - a.t)));
  let pos: V3, tgt: V3;
  if (a.orb && b.orb) {
    const o = { tgt: lerp3(a.orb.tgt, b.orb.tgt, x), r: a.orb.r + (b.orb.r - a.orb.r) * x, az: a.orb.az + (b.orb.az - a.orb.az) * x, el: a.orb.el + (b.orb.el - a.orb.el) * x };
    pos = orbPos(o); tgt = o.tgt;
  } else { const A = resolve(a), B = resolve(b); pos = lerp3(A.pos, B.pos, x); tgt = lerp3(A.tgt, B.tgt, x); }
  const zm: V3 = [0, 0, zmAt(t)];
  return { pos: add(pos, zm), target: add(tgt, zm), fov: a.fov + (b.fov - a.fov) * x, roll: (a.roll ?? 0) + ((b.roll ?? 0) - (a.roll ?? 0)) * x };
}
export const camAtFrame = (f: number) => cameraAt(f / FPS);
